import React from "react";
import { Header, Icon, Button, Modal } from "semantic-ui-react";
import OverrideAutomaticAdvancementsModal from "./modals/OverrideAutomaticAdvancements";
import StartEliminationsModal from "./modals/StartEliminationsModal";

class EliminationControls extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      rankingsModalOpen: false,
      overrideModalOpen: false,
      startEliminationsModalOpen: false
    };
  }

  handleRankingsModalOpen() {
    this.setState({
      rankingsModalOpen: true
    });
  }

  handleRankingsModalCancel() {
    this.setState({
      rankingsModalOpen: false
    });
  }

  handleOverrideModalOpen() {
    this.setState({
      overrideModalOpen: true
    });
  }

  handleOverrideModalCancel() {
    this.setState({
      overrideModalOpen: false
    });
  }

  handleStartEliminationsModalOpen() {
    this.setState({
      startEliminationsModalOpen: true
    });
  }

  handleStartEliminationsModalCancel() {
    this.setState({
      startEliminationsModalOpen: false
    });
  }

  render() {
    return (
      <div>
        <Header>Elimination Controls</Header>
        {!this.props.isStarted && (
          <div style={{ marginBottom: "15px" }}>
            <Icon name="exclamation triangle" />
            Eliminations have not been started yet.
          </div>
        )}
        {this.props.isStarted && (
          <div>
            {this.props.matches.map(match => {
              let color =
                this.props.currentMatch === match.num
                  ? "yellow"
                  : match.scores
                  ? "#21ba45"
                  : match.red1 && match.blue1 && match.eliminations.hide !== true
                  ? "#2185d0"
                  : "#e0e1e2";
              return <div className="eliminations-match-dot" key={match.num} style={{ background: color }}></div>;
            })}
            <div style={{ marginBottom: "10px" }} />
            <OverrideAutomaticAdvancementsModal
              open={this.state.overrideModalOpen}
              trigger={<Button style={{ marginBottom: "10px" }}>Override Automatic Advancements</Button>}
              handleOpen={this.handleOverrideModalOpen.bind(this)}
              handleCancel={this.handleOverrideModalCancel.bind(this)}
              handleSubmit={matches => {
                this.setState({
                  overrideModalOpen: false
                });
                this.props.handleOverrideEliminationAdvancements(matches);
              }}
              matches={this.props.matches}
              teamMenuOptions={this.props.teamMenuOptions}
            />
          </div>
        )}
        {!this.props.isStarted ? (
          <StartEliminationsModal
            open={this.state.startEliminationsModalOpen}
            trigger={<Button primary>Start Eliminations</Button>}
            handleOpen={this.handleStartEliminationsModalOpen.bind(this)}
            handleCancel={this.handleStartEliminationsModalCancel.bind(this)}
            handleSubmit={(size, doubleEliminations, selections) => {
              this.setState({
                startEliminationsModalOpen: false
              });
              this.props.handleStartEliminations(size, doubleEliminations, selections);
            }}
            teamMenuOptions={this.props.teamMenuOptions}
            rankings={this.props.sortedRankings}
          />
        ) : (
          <Button primary onClick={this.props.handleStartEliminations}>
            Stop Eliminations
          </Button>
        )}
        <Modal
          open={this.state.rankingsModalOpen}
          trigger={<Button>View Rankings</Button>}
          dimmer="inverted"
          size="small"
          onOpen={this.handleRankingsModalOpen.bind(this)}
          onClose={this.handleRankingsModalCancel.bind(this)}
        >
          <Header>Rankings</Header>
          <Modal.Content scrolling>
            <table>
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Team</th>
                  <th>Played</th>
                  {this.props.enableRankingPoints && <th>Avg. RP</th>}
                  <th>Wins</th>
                  <th>Ties</th>
                  <th>Losses</th>
                  <th>Avg. Score</th>
                  <th>Avg. Non-penalty</th>
                  <th>Total Penalty</th>
                </tr>
              </thead>
              <tbody>
                {this.props.sortedRankings.map(team => {
                  let total = Object.values(team.scoreHistory).length;
                  return (
                    <tr key={team.name} style={{ padding: ".2em .5em", textAlign: "center" }}>
                      <td>{team.rank}</td>
                      <td>{team.name}</td>
                      <td>{total}</td>
                      {this.props.enableRankingPoints && <td>{(team.totalRankingPoints / total || 0).toFixed(2)}</td>}
                      <td>{team.totalWins}</td>
                      <td>{team.totalTies}</td>
                      <td>{team.totalLosses}</td>
                      <td>{(team.totalMatchScore / total || 0).toFixed(2)}</td>
                      <td>{(team.totalPoints / total || 0).toFixed(2)}</td>
                      <td>{team.totalPenaltyPoints}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Modal.Content>
          <Modal.Actions>
            <Button
              labelPosition="right"
              icon="x"
              onClick={this.handleRankingsModalCancel.bind(this)}
              content="Close"
            />
          </Modal.Actions>
        </Modal>
      </div>
    );
  }
}

export default EliminationControls;
