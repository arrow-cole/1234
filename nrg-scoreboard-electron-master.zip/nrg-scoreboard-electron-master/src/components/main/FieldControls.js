import React from "react";
import { Header, Button, Label, Icon, Dropdown } from "semantic-ui-react";
import ScoringModal from "./modals/ScoringModal";
import AcceptLiveScoresModal from "./modals/AcceptLiveScoresModal";

function FieldControls(props) {
  let timeRemaining = undefined;
  if (props.matchRunning) {
    let minutes = Math.trunc(props.timeRemaining / 60);
    timeRemaining = (
      <Label>
        Time Remaining:&nbsp;
        {minutes}m&nbsp;
        {("000" + (props.timeRemaining - 60 * minutes)).slice(-2)}s
      </Label>
    );
  }
  return (
    <div className="field-controls">
      <Header>
        Field Controls
        <Label>Current Match: {props.match.eliminations ? props.match.eliminations.title : props.match.num}</Label>
        {timeRemaining}
      </Header>
      <div style={{ display: "flex" }}>
        <MatchButtons
          matchRunning={props.matchRunning}
          field={props.field}
          currentMatch={props.match}
          numMatches={props.numMatches}
          handleIncDecMatch={props.handleIncDecMatch}
          handleStartStopMatch={props.handleStartStopMatch}
          handleSetField={props.handleSetField}
        />
        <VerticalSeparator />
        <Scoring
          handleSubmitScores={props.handleSubmitScores}
          scores={props.match.scores}
          match={props.match}
          liveScoreEnabled={props.liveScoreEnabled}
          hasRedFinalScores={props.hasRedFinalScores}
          hasBlueFinalScores={props.hasBlueFinalScores}
          redFinalScores={props.redFinalScores}
          blueFinalScores={props.blueFinalScores}
          enableRankingPoints={props.enableRankingPoints}
        />
        <VerticalSeparator />
        <FieldOpModes opModes={props.opModes} handleChangeOpModes={props.handleChangeOpModes} />
      </div>
    </div>
  );
}

function MatchButtons(props) {
  return (
    <div className="match-buttons">
      <Button
        icon="backward"
        content="Previous Match"
        labelPosition="left"
        disabled={props.matchRunning || props.currentMatch.num === 1}
        onClick={() => {
          props.handleIncDecMatch(null, -1);
        }}
      />
      <Button
        icon="forward"
        content="Next Match"
        labelPosition="left"
        disabled={props.matchRunning || props.currentMatch.num === props.numMatches}
        onClick={() => {
          props.handleIncDecMatch(null, 1);
        }}
      />
      <Button
        icon="play"
        content="Start Match"
        color="green"
        labelPosition="left"
        disabled={props.matchRunning}
        onClick={() => props.handleStartStopMatch(true)}
      />
      <Button
        icon="stop"
        content="Abort Match"
        color="red"
        labelPosition="left"
        disabled={!props.matchRunning}
        onClick={() => props.handleStartStopMatch(false)}
      />
      Play match on:
      <Button.Group style={{ gridColumnStart: 1, gridColumnEnd: 3 }}>
        <Button active={props.field === 1} disabled={props.matchRunning} onClick={() => props.handleSetField(1)}>
          Field 1
        </Button>
        <Button active={props.field === 2} disabled={props.matchRunning} onClick={() => props.handleSetField(2)}>
          Field 2
        </Button>
      </Button.Group>
    </div>
  );
}

class Scoring extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showingScoreModal: false,
      showingLiveScoreModal: false
    };
  }

  handleScoresModalOpen() {
    this.setState({
      showingScoreModal: true
    });
  }

  handleScoresModalCancel() {
    this.setState({
      showingScoreModal: false
    });
  }

  handleLiveScoreModalOpen() {
    this.setState({
      showingLiveScoreModal: true
    });
  }

  handleLiveScoreModalCancel() {
    this.setState({
      showingLiveScoreModal: false
    });
  }

  render() {
    let liveScoreAlreadyAccepted =
      this.props.match && this.props.match.scores && this.props.match.scores.liveScoreBreakdown !== undefined;
    let redFinalScores =
      this.props.match && this.props.match.scores && this.props.match.scores.liveScoreBreakdown
        ? this.props.match.scores.liveScoreBreakdown.red
        : this.props.redFinalScores;
    let blueFinalScores =
      this.props.match && this.props.match.scores && this.props.match.scores.liveScoreBreakdown
        ? this.props.match.scores.liveScoreBreakdown.blue
        : this.props.blueFinalScores;

    return (
      <div>
        <Header size="small">Scoring</Header>
        {this.props.liveScoreEnabled && (
          <div>
            {liveScoreAlreadyAccepted ? (
              <div style={{ maxWidth: "200px", marginBottom: "10px" }}>
                <Icon name="info circle" />
                Live Scores have already been accepted for this match.
              </div>
            ) : (
              <div>
                <div>
                  <Icon name={this.props.hasRedFinalScores ? "check" : "exclamation circle"} />
                  {this.props.hasRedFinalScores ? "Red Scores Submitted" : "Waiting for red scores"}
                </div>
                <div style={{ marginBottom: "10px" }}>
                  <Icon name={this.props.hasBlueFinalScores ? "check" : "exclamation circle"} />
                  {this.props.hasBlueFinalScores ? "Blue Scores Submitted" : "Waiting for blue scores"}
                </div>
              </div>
            )}
            <AcceptLiveScoresModal
              open={this.state.showingLiveScoreModal}
              trigger={
                <Button
                  primary
                  fluid
                  disabled={
                    (!this.props.hasRedFinalScores || !this.props.hasBlueFinalScores) && !liveScoreAlreadyAccepted
                  }
                  style={{ marginBottom: "5px", minWidth: "215px" }}
                >
                  {liveScoreAlreadyAccepted ? "Edit Scores" : "Review/Accept Live Scores"}
                </Button>
              }
              handleOpen={this.handleLiveScoreModalOpen.bind(this)}
              handleCancel={this.handleLiveScoreModalCancel.bind(this)}
              handleSubmit={scores => {
                this.setState({
                  showingLiveScoreModal: false
                });
                this.props.handleSubmitScores(this.props.match.num, scores);
              }}
              match={this.props.match}
              redFinalScores={redFinalScores}
              blueFinalScores={blueFinalScores}
              enableRankingPoints={this.props.enableRankingPoints}
            />
          </div>
        )}
        {!this.props.liveScoreEnabled && (
          <div style={{ marginBottom: "10px" }}>
            <Icon name="info circle" />
            Live Score is not enabled.
          </div>
        )}
        <ScoringModal
          open={this.state.showingScoreModal}
          trigger={
            <Button
              primary={!this.props.liveScoreEnabled}
              basic={this.props.liveScoreEnabled}
              fluid
              disabled={this.props.liveScoreEnabled && liveScoreAlreadyAccepted}
              style={{ minWidth: "215px" }}
            >
              {!this.props.liveScoreEnabled && this.props.match.scores ? "Edit Scores" : "Enter Scores Manually"}
            </Button>
          }
          handleOpen={this.handleScoresModalOpen.bind(this)}
          handleCancel={this.handleScoresModalCancel.bind(this)}
          handleSubmit={scores => {
            this.setState({
              showingScoreModal: false
            });
            this.props.handleSubmitScores(this.props.match.num, scores);
          }}
          scores={this.props.scores}
          match={this.props.match}
          enableRankingPoints={this.props.enableRankingPoints}
        />
      </div>
    );
  }
}

function FieldOpModes(props) {
  return (
    <div>
      <Header size="small">Field Op Modes</Header>
      <FieldStateSelector
        field="1"
        opMode={props.opModes.field1}
        effectiveOpMode={props.opModes.field1Effective}
        handleChangeOpModes={props.handleChangeOpModes}
      />
      <FieldStateSelector
        field="2"
        opMode={props.opModes.field2}
        effectiveOpMode={props.opModes.field2Effective}
        handleChangeOpModes={props.handleChangeOpModes}
      />
      <Button basic fluid style={{ marginTop: "10px" }}>
        Connect/Disconnect Robots
      </Button>
    </div>
  );
}

function VerticalSeparator(props) {
  return <div style={{ width: "1px", margin: "0 10px", background: "lightgray" }} />;
}

function FieldStateSelector(props) {
  let opModeText = props.opMode.charAt(0).toUpperCase() + props.opMode.slice(1);
  if (props.opMode === "endgame") {
    opModeText = "End Game"; // fix formatting for this opMode
  } else if (props.opMode === "automatic") {
    if (props.effectiveOpMode !== "endgame") {
      opModeText += " (" + props.effectiveOpMode.charAt(0).toUpperCase() + props.effectiveOpMode.slice(1) + ")";
    } else {
      opModeText += " (End Game)";
    }
  }
  return (
    <div>
      Field {props.field}: &nbsp;
      <Dropdown text={opModeText}>
        <Dropdown.Menu>
          <Dropdown.Item text="Automatic" onClick={() => props.handleChangeOpModes(Number(props.field), "automatic")} />
          <Dropdown.Item text="Disabled" onClick={() => props.handleChangeOpModes(Number(props.field), "disabled")} />
          <Dropdown.Item
            text="Autonomous"
            onClick={() => props.handleChangeOpModes(Number(props.field), "autonomous")}
          />
          <Dropdown.Item text="Teleop" onClick={() => props.handleChangeOpModes(Number(props.field), "teleop")} />
          <Dropdown.Item text="End Game" onClick={() => props.handleChangeOpModes(Number(props.field), "endgame")} />
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
}

export default FieldControls;
