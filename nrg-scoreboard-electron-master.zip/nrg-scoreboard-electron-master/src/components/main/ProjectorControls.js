import React from "react";
import { Header, Button } from "semantic-ui-react";

function ProjectorControls(props) {
  return (
    <div>
      <Header>Projector Controls</Header>
      <div>
        <Header size="small">Current screen</Header>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "285px 145px 145px",
            gridGap: "5px"
          }}
        >
          <Button
            toggle
            active={props.projectorMode === "prematch-next"}
            disabled={!props.nextMatchPreviewAvailable || props.eliminations}
            onClick={() => {
              props.handleChangeProjectorMode("prematch-next");
            }}
          >
            Pre-Match / Rankings - Next Match
          </Button>
          <Button
            toggle
            active={props.projectorMode === "match-details"}
            onClick={() => {
              props.handleChangeProjectorMode("match-details");
            }}
          >
            Match Details
          </Button>
          <Button
            toggle
            active={props.projectorMode === "match-scores"}
            disabled={!props.scoresAvailable}
            onClick={() => {
              props.handleChangeProjectorMode("match-scores");
            }}
          >
            Match Scores
          </Button>
          <Button
            toggle
            active={props.projectorMode === "prematch-current"}
            disabled={props.eliminations}
            onClick={() => {
              props.handleChangeProjectorMode("prematch-current");
            }}
          >
            Pre-Match / Rankings - Current Match
          </Button>
          <Button
            toggle
            active={props.projectorMode === "nrg-logo-only"}
            onClick={() => {
              props.handleChangeProjectorMode("nrg-logo-only");
            }}
          >
            NRG Logo Only
          </Button>
          <Button
            toggle
            active={props.projectorMode === "black-only"}
            onClick={() => {
              props.handleChangeProjectorMode("black-only");
            }}
          >
            Black Only
          </Button>
          <Button
            toggle
            active={props.projectorMode === "elimination-bracket-next"}
            disabled={!props.nextMatchPreviewAvailable || !props.eliminations}
            onClick={() => {
              props.handleChangeProjectorMode("elimination-bracket-next");
            }}
          >
            Elimination Bracket - Next Match
          </Button>
          <div style={{ display: "flex", flexDirection: "row" }}>
            <Button
              toggle
              style={{ flexGrow: 1 }}
              active={props.projectorMode === "rankings"}
              onClick={() => {
                props.handleChangeProjectorMode("rankings");
              }}
            >
              Rankings
            </Button>
            <Button
              toggle
              active={props.rankingsScroll}
              icon="arrows alternate vertical"
              onClick={props.handleRankingsScrollChange}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "row" }}>
            <Button
              toggle
              style={{ flexGrow: 1 }}
              active={props.projectorMode === "awards"}
              onClick={() => {
                props.handleChangeProjectorMode("awards");
              }}
            >
              Awards
            </Button>
            <Button icon="settings" onClick={props.handleOpenAwardsSettings} />
          </div>
          <Button
            toggle
            active={props.projectorMode === "elimination-bracket-current"}
            disabled={!props.eliminations}
            onClick={() => {
              props.handleChangeProjectorMode("elimination-bracket-current");
            }}
          >
            Elimination Bracket - Current Match
          </Button>
        </div>
      </div>
    </div>
  );
}

export default ProjectorControls;
