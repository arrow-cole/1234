import React from "react";
import { Header, Button } from "semantic-ui-react";
import { Element, scroller } from "react-scroll";
import ScoringModal from "./modals/ScoringModal";

class MatchSchedule extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      modals: {}
    };
  }

  componentDidUpdate(prevProps) {
    if (prevProps.currentMatch !== this.props.currentMatch) {
      scroller.scrollTo(String(this.props.currentMatch), {
        containerId: "match-schedule",
        smooth: true,
        offset: -150
      });
    }
  }

  handleOpen(num) {
    let modals = this.state.modals;
    modals[num] = true;
    this.setState({
      modals: modals
    });
  }

  handleCancel(num) {
    let modals = this.state.modals;
    modals[num] = false;
    this.setState({
      modals: modals
    });
  }

  render() {
    let schedule = this.props.matches
      .filter(match => {
        return (
          match.red1 && match.red2 && match.blue1 && match.blue2 && !(match.eliminations && match.eliminations.hide)
        );
      })
      .map((match, index) => (
        <Element
          name={String(match.num)}
          key={match.num}
          className={"match-card" + (this.props.currentMatch === match.num ? " active" : "")}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between"
            }}
          >
            <Header size="small" style={{ margin: 0 }}>
              {match.eliminations ? match.eliminations.shortTitle : "Match " + match.num}
            </Header>
            <div>
              <Button
                compact
                icon="external alternate"
                style={{ margin: 0, marginRight: 10 }}
                onClick={() => {
                  var confirmation = window.confirm(
                    "Are you sure you want to switch to " +
                      (match.eliminations ? match.eliminations.title : "Match " + match.num) +
                      "?"
                  );
                  if (confirmation) {
                    this.props.handleIncDecMatch(match.num);
                  }
                }}
              />

              <ScoringModal
                trigger={<Button compact icon="edit" style={{ margin: 0 }} />}
                open={this.state.modals[match.num]}
                handleOpen={() => {
                  this.handleOpen.bind(this)(match.num);
                }}
                handleCancel={() => {
                  this.handleCancel.bind(this)(match.num);
                }}
                handleSubmit={scores => {
                  let modals = this.state.modals;
                  modals[match.num] = false;
                  this.setState({
                    modals: modals
                  });
                  this.props.handleSubmitScores(match.num, scores);
                }}
                scores={match.scores}
                match={match}
                rankingPointsEnabled={this.props.rankingPointsEnabled}
              />
            </div>
          </div>
          <div
            style={{
              display: "grid",
              alignItems: "center",
              gridTemplateColumns: "1fr auto 1fr"
            }}
          >
            <div style={{ color: "red" }}>
              <div style={{ fontStyle: match.surrogates && match.surrogates.red1 ? "italic" : "normal" }}>
                {match.red1 + (match.surrogates && match.surrogates.red1 ? "**" : "")}
              </div>
              <div style={{ fontStyle: match.surrogates && match.surrogates.red2 ? "italic" : "normal" }}>
                {match.red2 + (match.surrogates && match.surrogates.red2 ? "**" : "")}
              </div>
            </div>
            {match.scores !== undefined ? (
              <div style={{ textAlign: "center" }}>
                {this.props.enableRankingPoints && (
                  <div style={{ fontSize: "11px" }}>
                    {match.scores.redRankingPoints} RP - {match.scores.blueRankingPoints} RP
                  </div>
                )}
                <div style={{ fontSize: "25px" }}>
                  {match.scores.red} - {match.scores.blue}
                </div>
                <div style={{ fontSize: "11px" }}>
                  ({match.scores.bluePenalty}) - ({match.scores.redPenalty})
                </div>
              </div>
            ) : (
              <div
                style={{
                  height: "57px",
                  display: "flex",
                  alignItems: "center",
                  fontStyle: "italic"
                }}
              >
                Not scored yet
              </div>
            )}
            <div style={{ color: "dodgerblue", textAlign: "right" }}>
              <div style={{ fontStyle: match.surrogates && match.surrogates.blue1 ? "italic" : "normal" }}>
                {match.blue1 + (match.surrogates && match.surrogates.blue1 ? "**" : "")}
              </div>
              <div style={{ fontStyle: match.surrogates && match.surrogates.blue2 ? "italic" : "normal" }}>
                {match.blue2 + (match.surrogates && match.surrogates.blue2 ? "**" : "")}
              </div>
            </div>
          </div>
        </Element>
      ));

    return (
      <Element className="match-schedule" id="match-schedule">
        <Header>Match Schedule</Header>
        {schedule}
      </Element>
    );
  }
}

export default MatchSchedule;
