import React from "react";
import { Button, Input } from "semantic-ui-react";
import { animateScroll as scroll } from "react-scroll";

class TeamNames extends React.Component {
  constructor(props) {
    super(props);

    if (this.props.teams === null || this.props.teams.length === 0) {
      this.props.updateTeamsHandler(["", "", "", ""]);
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.teams.length > prevProps.teams.length) {
      scroll.scrollToBottom({ isDynamic: true });
    }
  }

  render() {
    var test = this.props.teams.map((team, index) => (
      <div key={index} style={{ marginBottom: "5px" }}>
        <Input
          value={team}
          error={this.props.duplicates.includes(team)}
          placeholder="Enter Name"
          size="large"
          style={{
            width: "275px",
            marginRight: "5px"
          }}
          onChange={(event, data) => {
            let teams = [].concat(this.props.teams);
            teams[index] = data.value;
            if (teams.length > 0 && teams[teams.length - 1] !== "") {
              teams.push("");
            }
            this.props.updateTeamsHandler(teams);
          }}
        />
        <Button
          icon="trash"
          size="large"
          tabIndex="-1"
          onClick={() => {
            let teams = this.props.teams;
            teams.splice(index, 1);
            this.props.updateTeamsHandler(teams);
          }}
        />
      </div>
    ));
    return (
      <div
        style={{
          textAlign: "center",
          margin: "0 auto",
          display: "inline-block",
          overflow: "auto"
        }}
      >
        {test}
        <Button
          onClick={() => {
            let teams = [].concat(this.props.teams);
            teams.push("");
            this.props.updateTeamsHandler(teams);
          }}
        >
          Add Another Team
        </Button>
      </div>
    );
  }
}

export default TeamNames;
