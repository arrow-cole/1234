import React from "react";
import { Redirect, Link } from "react-router-dom";
import { Header, Button } from "semantic-ui-react";

function SetupLoadBackup(props) {
  if (props.backup === null || props.backup.matches === null || props.backup.matches.length === 0) {
    return <Redirect to="/setupTeams" />;
  } else {
    return (
      <div
        style={{
          maxWidth: "300px",
          textAlign: "center",
          margin: "0 auto",
          padding: "30px"
        }}
      >
        <Header size="huge">Load from Backup</Header>
        <p>A backup.json file was detected. Do you want to reload from this saved state?</p>
        <Link to="/">
          <Button
            style={{ marginBottom: "10px", width: "200px" }}
            onClick={() => {
              props.loadBackupHandler(true);
            }}
          >
            Yes, reload from backup.
          </Button>
        </Link>
        <Link to="/setupTeams">
          <Button
            style={{ width: "200px" }}
            onClick={() => {
              props.loadBackupHandler(false);
            }}
          >
            No, ignore the backup.
          </Button>
        </Link>
      </div>
    );
  }
}

export default SetupLoadBackup;
