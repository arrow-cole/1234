import React from "react";
import { Header, Divider, Checkbox, Input, Dropdown, Button } from "semantic-ui-react";
import { Link } from "react-router-dom";
import Rankings from "../../util/rankings";
import { getBackupFilePath } from "../../util/util.js";

const electron = window.require("electron");
const remote = window.require("@electron/remote");

class SettingsPage extends React.Component {
  handleRankingOrderSelection(index, data) {
    let oldValue = this.props.state.rankingOrderSelections[index];
    let selections = this.props.state.rankingOrderSelections;
    for (let i = 0; i < selections.length; i++) {
      if (selections[i] === data.value) {
        selections[i] = oldValue;
        break;
      }
    }
    selections[index] = data.value;
    this.props.handleSaveSettings({
      ...this.props.state,
      rankingOrderSelections: selections,
    });
  }

  render() {
    const rankingOptions = [
      ...(this.props.state.enableRankingPoints
        ? [
            {
              key: "ranking-points",
              text: "Ranking Points",
              value: Rankings.RankingOrderOptions.RANKING_POINTS,
            },
          ]
        : []),
      {
        key: "least-penalty-points",
        text: "Least Penalty Points",
        value: Rankings.RankingOrderOptions.LEAST_PENALTY_POINTS,
      },
      {
        key: "average-match-score",
        text: "Average Match Score",
        value: Rankings.RankingOrderOptions.AVERAGE_MATCH_SCORE,
      },
      {
        key: "average-non-penalty-points",
        text: "Average Non-Penalty Points",
        value: Rankings.RankingOrderOptions.AVERAGE_NON_PENALTY_POINTS,
      },
      {
        key: "wins",
        text: "Wins",
        value: Rankings.RankingOrderOptions.WINS,
      },
    ];
    return (
      <div>
        <Header size="huge" style={{ textAlign: "center", margin: "20px" }}>
          Settings
        </Header>
        <div className="settings-container">
          <Header size="large">Match</Header>
          <Checkbox
            label="Play Sounds"
            checked={this.props.state.audio.enable}
            onChange={(e, data) => {
              this.props.handleSaveSettings({
                ...this.props.state,
                audio: {
                  ...this.props.state.audio,
                  enable: data.checked,
                },
              });
            }}
          />
          <Checkbox
            label="Enable Autonomous"
            checked={this.props.state.enableAutonomous}
            onChange={(e, data) => {
              this.props.handleSaveSettings({
                ...this.props.state,
                enableAutonomous: data.checked,
              });
            }}
          />
          <Checkbox
            label="Enable Endgame"
            checked={this.props.state.enableEndGame}
            onChange={(e, data) => {
              this.props.handleSaveSettings({
                ...this.props.state,
                enableEndGame: data.checked,
              });
            }}
          />
          <div className="settings-grid">
            <div>Total Match Duration</div>
            <Input
              label="seconds"
              labelPosition="right"
              value={this.props.state.matchDuration}
              onChange={(e, data) => {
                if (Number(data.value) >= 0) {
                  this.props.handleSaveSettings({
                    ...this.props.state,
                    matchDuration: data.value,
                    teleopStart: data.value - (this.props.state.matchDuration - this.props.state.teleopStart),
                  });
                }
              }}
            />
            {this.props.state.enableAutonomous && <div>Autonomous Duration</div>}
            {this.props.state.enableAutonomous && (
              <Input
                label="seconds"
                labelPosition="right"
                value={this.props.state.matchDuration - this.props.state.teleopStart}
                onChange={(e, data) => {
                  if (Number(data.value) >= 0) {
                    this.props.handleSaveSettings({
                      ...this.props.state,
                      teleopStart: this.props.state.matchDuration - data.value,
                    });
                  }
                }}
              />
            )}
            {this.props.state.enableEndGame && <div>End Game Duration</div>}
            {this.props.state.enableEndGame && (
              <Input
                label="seconds"
                labelPosition="right"
                value={this.props.state.endGameStart}
                onChange={(e, data) => {
                  if (Number(data.value) >= 0) {
                    this.props.handleSaveSettings({
                      ...this.props.state,
                      endGameStart: data.value,
                    });
                  }
                }}
              />
            )}
          </div>
          <Divider />
          <Header size="large">Live Score</Header>
          <Checkbox
            label="Enable Live Score"
            checked={this.props.state.liveScore.enabled}
            onChange={(e, data) => {
              this.props.handleSaveSettings({
                ...this.props.state,
                liveScore: {
                  ...this.props.state.liveScore,
                  enabled: data.checked,
                },
              });
            }}
          />
          <div>
            Live Score App Location: {this.props.state.liveScore.appLocation}
            <Button
              style={{ marginLeft: "10px" }}
              content="Change"
              onClick={() => {
                remote.dialog
                  .showOpenDialog({
                    title: "Select Live Score App Location",
                    defaultPath: getBackupFilePath(),
                    properties: ["openDirectory"],
                  })
                  .then((data) => {
                    this.props.handleSaveSettings({
                      ...this.props.state,
                      liveScore: {
                        ...this.props.state.liveScore,
                        appLocation: data.filePaths[0],
                      },
                    });
                    electron.ipcRenderer.send("set-livescore-app-location", data.filePaths[0]);
                  });
              }}
            />
          </div>
          <Divider />
          <Header size="large">Network</Header>
          <div className="settings-grid">
            <div>MQTT Broker Location</div>
            <Input
              value={this.props.state.mqttBrokerLocation}
              onChange={(e, data) => {
                this.props.handleSaveSettings({
                  ...this.props.state,
                  mqttBrokerLocation: data.value,
                });
              }}
            />
          </div>
          <Divider />
          <Header size="large">Rankings</Header>
          <Checkbox
            label="Enable Ranking Points"
            checked={this.props.state.enableRankingPoints}
            onChange={(e, data) => {
              let selections = this.props.state.rankingOrderSelections;
              for (let i = 0; i < selections.length; i++) {
                if (selections[i] === Rankings.RankingOrderOptions.RANKING_POINTS) {
                  selections.splice(i, 1);
                }
              }
              selections.push(Rankings.RankingOrderOptions.RANKING_POINTS);
              this.props.handleSaveSettings({
                ...this.props.state,
                enableRankingPoints: data.checked,
              });
            }}
          />
          <div className="settings-grid" style={{ textAlign: "right" }}>
            <div>Rank teams by</div>
            <Dropdown
              selection
              options={rankingOptions}
              value={this.props.state.rankingOrderSelections[0]}
              onChange={(e, data) => {
                this.handleRankingOrderSelection.bind(this)(0, data);
              }}
            />
            <div>Then by</div>
            <Dropdown
              selection
              options={rankingOptions}
              value={this.props.state.rankingOrderSelections[1]}
              onChange={(e, data) => {
                this.handleRankingOrderSelection.bind(this)(1, data);
              }}
            />
            <div>Then by</div>
            <Dropdown
              selection
              options={rankingOptions}
              value={this.props.state.rankingOrderSelections[2]}
              onChange={(e, data) => {
                this.handleRankingOrderSelection.bind(this)(2, data);
              }}
            />
            <div>Then by</div>
            <Dropdown
              selection
              options={rankingOptions}
              value={this.props.state.rankingOrderSelections[3]}
              onChange={(e, data) => {
                this.handleRankingOrderSelection.bind(this)(3, data);
              }}
            />
            {this.props.state.enableRankingPoints && <div>Then by</div>}
            {this.props.state.enableRankingPoints && (
              <Dropdown
                selection
                options={rankingOptions}
                value={this.props.state.rankingOrderSelections[4]}
                onChange={(e, data) => {
                  this.handleRankingOrderSelection.bind(this)(4, data);
                }}
              />
            )}
          </div>
          <Divider />
          <Header size="large">Game-specific settings</Header>
          <Header size="medium">Pyramid Puzzle</Header>
          <Checkbox
            label="Show hot color when endgame starts"
            checked={this.props.state.enablePyramidPuzzleHotColor}
            onChange={(e, data) => {
              this.props.handleSaveSettings({
                ...this.props.state,
                enablePyramidPuzzleHotColor: data.checked,
              });
            }}
          />
        </div>
        <Link to="/" style={{ position: "fixed", top: "30px", right: "30px" }}>
          <Button icon="close" />
        </Link>
      </div>
    );
  }
}

export default SettingsPage;
