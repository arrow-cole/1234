import React from "react";
import TeamNames from "./TeamNames";
import { Header, Input, Button, Checkbox, Dropdown, Icon } from "semantic-ui-react";
import { Redirect } from "react-router-dom";
import ScheduleGenerator from "../../util/schedule_generator.js";

const electron = window.require("electron");

class SetupMatchSchedule extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      teams: [],
      numTeams: 0,
      numMatches: 0,
      generationStyle: "per-team",
      enforcePlaytimeEquity: true,
      useSurrogateMatches: true,
      redirectToMainPage: false
    };
  }

  updateTeamsHandler(teams) {
    this.setState({
      teams: teams,
      numTeams: teams.filter(team => {
        return team !== "";
      }).length
    });
  }

  updateNumMatches(e, data) {
    this.setState({
      numMatches: data.value
    });
  }

  updateEnforcePlaytimeEquity(e, data) {
    this.setState({
      enforcePlaytimeEquity: data.checked
    });
  }

  updateUseSurrogateMatches(e, data) {
    this.setState({
      useSurrogateMatches: data.checked
    });
  }

  updateGenerationStyle(e, data) {
    this.setState({
      generationStyle: data.value
    });
  }

  increaseCalculatedNumMatches() {
    let numTeams = this.state.numTeams;
    let num = this.state.numMatches;
    if (numTeams === 0) {
      num++;
    } else {
      if (this.state.generationStyle === "per-team") {
        do {
          num++;
        } while ((numTeams * num) % 4 !== 0);
      } else {
        do {
          num++;
        } while ((num * 4) % numTeams !== 0);
      }
    }
    this.setState({
      numMatches: num
    });
  }

  decreaseCalculatedNumMatches() {
    let numTeams = this.state.numTeams;
    let num = this.state.numMatches;
    if (numTeams === 0) {
      num--;
    } else {
      if (this.state.generationStyle === "per-team") {
        do {
          num--;
        } while (num > 0 && (numTeams * num) % 4 !== 0);
      } else {
        do {
          num--;
        } while (num > 0 && (num * 4) % numTeams !== 0);
      }
    }
    this.setState({
      numMatches: num
    });
  }

  skipMatchScheduleGeneration() {
    let practiceMatch = {
      num: 1,
      red1: "Red 1",
      red2: "Red 2",
      blue1: "Blue 1",
      blue2: "Blue 2"
    };
    this.props.generateMatchesHandler([practiceMatch], ["Red 1", "Red 2", "Blue 1", "Blue 2"]);
    this.setState({
      redirectToMainPage: true
    });
  }

  generateMatchSchedule() {
    let teams = this.state.teams.filter(team => {
      return team !== "";
    });
    let generator = new ScheduleGenerator(
      this.state.generationStyle,
      this.state.enforcePlaytimeEquity,
      this.state.useSurrogateMatches
    );
    let schedule = generator.generateSchedule(this.state.numMatches, teams);
    let matchesPerTeam = Math.floor(
      this.state.generationStyle === "per-team"
        ? this.state.numMatches
        : (this.state.numMatches * 4) / this.state.numTeams
    );
    this.props.generateMatchesHandler(schedule, teams, matchesPerTeam);
    this.setState({
      redirectToMainPage: true
    });
    electron.ipcRenderer.send("app-loaded-schedule", true);
  }

  render() {
    if (this.state.redirectToMainPage) {
      return <Redirect to="/" />;
    }

    let numMatchesInSchedule =
      this.state.generationStyle === "total"
        ? this.state.numMatches
        : (this.state.numMatches * this.state.numTeams) / 4;
    let minutesToComplete = numMatchesInSchedule * 7;
    let timeEstimate =
      minutesToComplete < 60
        ? minutesToComplete + " minutes"
        : Math.floor(minutesToComplete / 60) +
          " hours and " +
          (minutesToComplete - Math.floor(minutesToComplete / 60) * 60) +
          " minutes";
    let occurrences = {};
    let duplicates = [];
    this.state.teams.forEach(team => {
      if (occurrences[team] && team !== "") {
        duplicates.push(team);
      }
      occurrences[team] = true;
    });
    return (
      <div
        style={{
          textAlign: "center",
          padding: "30px",
          height: "100vh"
        }}
      >
        <Header size="huge">Setup Match Schedule</Header>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gridGap: "20px",
            position: "absolute",
            left: "0",
            right: "0",
            bottom: "40px",
            top: "100px"
          }}
        >
          <div style={{ textAlign: "left", margin: "0 auto" }}>
            <Checkbox
              toggle
              label="Enforce Playtime Equity"
              checked={this.state.enforcePlaytimeEquity}
              onChange={this.updateEnforcePlaytimeEquity.bind(this)}
            />
            <p
              style={{
                maxWidth: "350px",
                margin: "5px 0 30px 0",
                fontStyle: "italic"
              }}
            >
              <Icon name="help circle" />
              When this option is enabled, only configurations where each team will play the same number of matches are
              allowed. The number of valid schedule lengths could be limited depending on how many teams are competing.
            </p>
            <Dropdown
              selection
              fluid
              value={this.state.generationStyle}
              onChange={this.updateGenerationStyle.bind(this)}
              options={[
                {
                  key: 1,
                  text: "Each team should play...",
                  value: "per-team"
                },
                {
                  key: 2,
                  text: "There should be a total of...",
                  value: "total"
                }
              ]}
              style={{ marginBottom: "10px" }}
            />
            {this.state.enforcePlaytimeEquity ? (
              <div style={{ marginBottom: "10px" }}>
                {this.state.numMatches} Matches&nbsp;
                <Button
                  icon="minus"
                  disabled={this.state.numMatches <= 0}
                  onClick={this.decreaseCalculatedNumMatches.bind(this)}
                />
                <Button icon="add" onClick={this.increaseCalculatedNumMatches.bind(this)} />
              </div>
            ) : (
              <Input
                placeholder="Enter number"
                label="Matches"
                fluid
                labelPosition="right"
                value={this.state.numMatches || ""}
                onChange={this.updateNumMatches.bind(this)}
                style={{ marginBottom: "10px" }}
              />
            )}
            {!this.state.enforcePlaytimeEquity && (
              <Checkbox
                label="Use Surrogate Matches"
                checked={this.state.useSurrogateMatches}
                onChange={this.updateUseSurrogateMatches.bind(this)}
                style={{
                  marginBottom: "30px"
                }}
              />
            )}
            {this.state.generationStyle === "per-team" ? (
              <div style={{ fontWeight: "bold" }}>
                This will result in a total of{" "}
                {parseFloat(((this.state.numTeams * this.state.numMatches) / 4).toFixed(2))} matches.
              </div>
            ) : (
              <div style={{ fontWeight: "bold" }}>
                This will result in {parseFloat(((this.state.numMatches * 4) / this.state.numTeams).toFixed(2))} matches
                per team.
              </div>
            )}
            <p
              style={{
                maxWidth: "350px"
              }}
            >
              Note: Assuming a 7 minute cycle time, qualification matches will take {timeEstimate} to complete.
            </p>
            <Button
              primary
              disabled={
                !(Number(this.state.numMatches) > 0) ||
                this.state.numTeams < 4 ||
                (this.state.enforcePlaytimeEquity &&
                  !(
                    (this.state.generationStyle === "per-team" &&
                      (this.state.numTeams * this.state.numMatches) % 4 === 0) ||
                    (this.state.generationStyle === "total" && (this.state.numMatches * 4) % this.state.numTeams === 0)
                  ))
              }
              onClick={this.generateMatchSchedule.bind(this)}
              style={{ marginTop: "30px" }}
            >
              Generate Match Schedule
            </Button>
            <Button onClick={this.skipMatchScheduleGeneration.bind(this)} style={{ marginTop: "30px" }} basic>
              Skip Match Schedule Generation
            </Button>
            {duplicates.length > 0 && (
              <div style={{ marginTop: "20px", color: "red", fontWeight: "bold" }}>
                Duplicate team names are not allowed.
              </div>
            )}
          </div>
          <TeamNames
            teams={this.state.teams}
            updateTeamsHandler={this.updateTeamsHandler.bind(this)}
            duplicates={duplicates}
          />
        </div>
      </div>
    );
  }
}

export default SetupMatchSchedule;
