import React from "react";
import { Header, Icon } from "semantic-ui-react";

function FieldStatus(props) {
  return (
    <div style={{ marginRight: "30px" }}>
      <Header>System Status</Header>
      <div style={{ display: "flex" }}>
        <div style={{ marginRight: "30px" }}>
          <Header size="small">Field 1</Header>
          <StatusIndicator state={props.status.field1.fcs} name="FCS" />
          <StatusIndicator state={props.status.field1.red1} isRobot={true} name="Red 1" />
          <StatusIndicator state={props.status.field1.red2} isRobot={true} name="Red 2" />
          <StatusIndicator state={props.status.field1.blue1} isRobot={true} name="Blue 1" />
          <StatusIndicator state={props.status.field1.blue2} isRobot={true} name="Blue 2" />
        </div>
        <div style={{ marginRight: "30px" }}>
          <Header size="small">Field 2</Header>
          <StatusIndicator state={props.status.field2.fcs} name="FCS" />
          <StatusIndicator state={props.status.field2.red1} isRobot={true} name="Red 1" />
          <StatusIndicator state={props.status.field2.red2} isRobot={true} name="Red 2" />
          <StatusIndicator state={props.status.field2.blue1} isRobot={true} name="Blue 1" />
          <StatusIndicator state={props.status.field2.blue2} isRobot={true} name="Blue 2" />
        </div>
        <div>
          <Header size="small">Other </Header>
          <StatusIndicator state={props.status.other.mqtt} name="MQTT Broker" />
          <StatusIndicator
            state={props.status.other.liveScore}
            name="LiveScore Server"
          />
          <div style={{ marginBottom: "5px" }}>
            <Icon name="mobile alternate" />{" "}
            {props.status.other.liveScorePhones} phones using LiveScore
          </div>
          <StatusIndicator
            state={props.status.other.queueing}
            name="Queueing Server"
          />
        </div>
      </div>
    </div>
  );
}

function StatusIndicator(props) {
  let color =
    props.state === "connected"
      ? "lime"
      : props.state === "indeterminate"
      ? "orange"
      : "red";
  if (props.isRobot) {
    color = 
      props.state === "disconnected"
        ? "orange"
        : props.state === "norobot"
        ? "red"
        : "lime";
  }
  return (
    <div style={{ display: "flex", marginBottom: "5px" }}>
      <div
        style={{
          borderRadius: "50%",
          background: color,
          width: "20px",
          height: "20px",
          marginRight: "5px"
        }}
      />
      {props.name}
    </div>
  );
}

export default FieldStatus;
