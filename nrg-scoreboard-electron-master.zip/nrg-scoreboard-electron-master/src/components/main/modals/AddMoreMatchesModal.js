import React from "react";
import { Modal, Input, Button, Header, Checkbox, Icon, Dropdown } from "semantic-ui-react";
import ScheduleGenerator from "../../../util/schedule_generator";

class AddMoreMatchesModal extends React.PureComponent {
  constructor(props) {
    super();
    this.state = {
      numMatches: 0,
      generationStyle: "per-team",
      enforcePlaytimeEquity: true,
      useSurrogateMatches: true
    };
  }

  // shouldComponentUpdate() {
  //   return this.props.open;
  // }

  updateNumMatches(e, data) {
    this.setState({
      numMatches: data.value
    });
  }

  updateEnforcePlaytimeEquity(e, data) {
    this.setState({
      enforcePlaytimeEquity: data.checked
    });
  }

  updateUseSurrogateMatches(e, data) {
    this.setState({
      useSurrogateMatches: data.checked
    });
  }

  updateGenerationStyle(e, data) {
    this.setState({
      generationStyle: data.value
    });
  }

  increaseCalculatedNumMatches() {
    let numTeams = this.props.teamMenuOptions.length;
    let num = this.state.numMatches;
    if (numTeams === 0) {
      num++;
    } else {
      if (this.state.generationStyle === "per-team") {
        do {
          num++;
        } while ((numTeams * num) % 4 !== 0);
      } else {
        do {
          num++;
        } while ((num * 4) % numTeams !== 0);
      }
    }
    this.setState({
      numMatches: num
    });
  }

  decreaseCalculatedNumMatches() {
    let numTeams = this.props.teamMenuOptions.length;
    let num = this.state.numMatches;
    if (numTeams === 0) {
      num--;
    } else {
      if (this.state.generationStyle === "per-team") {
        do {
          num--;
        } while (num > 0 && (numTeams * num) % 4 !== 0);
      } else {
        do {
          num--;
        } while (num > 0 && (num * 4) % numTeams !== 0);
      }
    }
    this.setState({
      numMatches: num
    });
  }

  handleCancel() {
    this.setState({
      teamName: "",
      formInvalid: true
    });
    this.props.handleCancel();
  }

  render() {
    let numMatchesInSchedule =
      this.state.generationStyle === "total"
        ? this.state.numMatches
        : (this.state.numMatches * this.props.teamMenuOptions.length) / 4;
    let minutesToComplete = numMatchesInSchedule * 7;
    let timeEstimate =
      minutesToComplete < 60
        ? minutesToComplete + " minutes"
        : Math.floor(minutesToComplete / 60) +
          " hours and " +
          (minutesToComplete - Math.floor(minutesToComplete / 60) * 60) +
          " minutes";

    return (
      <Modal open={this.props.open} dimmer="inverted" size="small" onClose={this.handleCancel.bind(this)}>
        <Header>Add More Qualification Matches</Header>
        <Modal.Content>
          <Checkbox
            toggle
            label="Enforce Playtime Equity"
            checked={this.state.enforcePlaytimeEquity}
            onChange={this.updateEnforcePlaytimeEquity.bind(this)}
          />
          <p
            style={{
              margin: "5px 0 30px 0",
              fontStyle: "italic"
            }}
          >
            <Icon name="help circle" />
            When this option is enabled, only configurations where each team will play the same number of matches are
            allowed. The number of valid schedule lengths could be limited depending on how many teams are competing.
            Note this only applies to the additional matches being generated and not the existing matches.
          </p>
          <Dropdown
            selection
            fluid
            value={this.state.generationStyle}
            onChange={this.updateGenerationStyle.bind(this)}
            options={[
              {
                key: 1,
                text: "Each team should play...",
                value: "per-team"
              },
              {
                key: 2,
                text: "There should be a total of...",
                value: "total"
              }
            ]}
            style={{ marginBottom: "10px" }}
          />
          {this.state.enforcePlaytimeEquity ? (
            <div style={{ marginBottom: "10px" }}>
              {this.state.numMatches} Additional Matches&nbsp;
              <Button
                icon="minus"
                disabled={this.state.numMatches <= 0}
                onClick={this.decreaseCalculatedNumMatches.bind(this)}
              />
              <Button icon="add" onClick={this.increaseCalculatedNumMatches.bind(this)} />
            </div>
          ) : (
            <Input
              placeholder="Enter number"
              label="Additional Matches"
              fluid
              labelPosition="right"
              value={this.state.numMatches || ""}
              onChange={this.updateNumMatches.bind(this)}
              style={{ marginBottom: "10px" }}
            />
          )}
          {!this.state.enforcePlaytimeEquity && (
            <Checkbox
              label="Use Surrogate Matches"
              checked={this.state.useSurrogateMatches}
              onChange={this.updateUseSurrogateMatches.bind(this)}
              style={{
                marginBottom: "30px"
              }}
            />
          )}
          {this.state.generationStyle === "per-team" ? (
            <div style={{ fontWeight: "bold" }}>
              This will result in a total of{" "}
              {parseFloat(((this.props.teamMenuOptions.length * this.state.numMatches) / 4).toFixed(2))} additional matches.
            </div>
          ) : (
            <div style={{ fontWeight: "bold" }}>
              This will result in {parseFloat(((this.state.numMatches * 4) / this.props.teamMenuOptions.length).toFixed(2))}{" "}
              more matches per team.
            </div>
          )}
          <p>
            Note: Assuming a 7 minute cycle time, these extra qualification matches will take {timeEstimate} to
            complete.
          </p>
        </Modal.Content>
        <Modal.Actions>
          <Button labelPosition="right" icon="x" onClick={this.handleCancel.bind(this)} content="Cancel" />
          <Button
            primary
            labelPosition="right"
            icon="save"
            disabled={!(Number(this.state.numMatches) > 0)}
            onClick={() => {
              let generator = new ScheduleGenerator(
                this.state.generationStyle,
                this.state.enforcePlaytimeEquity,
                this.state.useSurrogateMatches
              );
              generator.startingMatchNumber = this.props.numMatches + 1;
              let schedule = generator.generateSchedule(
                this.state.numMatches,
                this.props.teamMenuOptions.map(team => {
                  return team.key;
                })
              );
              let additionalMatchesPerTeam = Math.floor(
                this.state.generationStyle === "per-team"
                  ? this.state.numMatches
                  : (this.state.numMatches * 4) / this.props.teamMenuOptions.length
              );
              this.props.handleSubmit(schedule, additionalMatchesPerTeam);
              this.setState({
                numMatches: 0
              });
            }}
            content="Generate Extra Matches"
          />
        </Modal.Actions>
      </Modal>
    );
  }
}

export default AddMoreMatchesModal;
