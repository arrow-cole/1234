import React from "react";
import { Header, Dropdown, Button, Modal, Checkbox } from "semantic-ui-react";

class StartEliminationsModal extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      eliminationsSize: 8,
      doubleElimination: true,
      teamSelections: [["", ""], ["", ""], ["", ""], ["", ""], ["", ""], ["", ""], ["", ""], ["", ""]],
      sizeOptions: []
    };
  }

  // shouldComponentUpdate() {
  //   return this.props.open;
  // }

  handleOpen() {
    let sizeOptions = [
      {
        key: 1,
        text: "Eight Alliances",
        value: 8
      },
      {
        key: 2,
        text: "Four Alliances",
        value: 4
      },
      {
        key: 3,
        text: "Two Alliances",
        value: 2
      }
    ];

    let maxEliminationsSize = this.props.teamMenuOptions.length >= 16 ? 8 : this.props.teamMenuOptions.length >= 8 ? 4 : 2;
    let teamSelections = this.getDefaultSelections(maxEliminationsSize);

    this.setState({
      eliminationsSize: maxEliminationsSize,
      sizeOptions:
        maxEliminationsSize === 8 ? sizeOptions : maxEliminationsSize === 4 ? sizeOptions.slice(1) : sizeOptions.slice(2),
      teamSelections: teamSelections
    });

    /* call the parent's handler */
    this.props.handleOpen();
  }

  getDefaultSelections(eliminationsSize) {
    let teamSelections = this.state.eliminationsSize;
    if (this.props.rankings.length >= eliminationsSize * 2) {
      teamSelections = [];
      for (let i = 0; i < eliminationsSize; i++) {
        teamSelections.push([this.props.rankings[i].name, this.props.rankings[eliminationsSize * 2 - i - 1].name]);
      }
    }
    return teamSelections;
  }

  updateEliminationsSize(event, data) {
    let teamSelections = this.getDefaultSelections(data.value, this.props.teamMenuOptions);

    this.setState({
      eliminationsSize: data.value,
      teamSelections: teamSelections
    });
  }

  updateDoubleElimination(event, data) {
    this.setState({
      doubleElimination: data.checked
    });
  }

  handleSelectedTeamChange(allianceIndex, teamIndex, team) {
    let teamSelections = this.state.teamSelections;
    let oldTeam = teamSelections[allianceIndex][teamIndex];
    for (let i = 0; i < teamSelections.length; i++) {
      if (teamSelections[i][0] === team) {
        teamSelections[i][0] = oldTeam;
      }
      if (teamSelections[i][1] === team) {
        teamSelections[i][1] = oldTeam;
      }
    }
    teamSelections[allianceIndex][teamIndex] = team;
    this.setState({
      teamSelections: teamSelections
    });
  }

  render() {
    return (
      <Modal
        open={this.props.open}
        trigger={this.props.trigger}
        dimmer="inverted"
        size="small"
        onOpen={this.handleOpen.bind(this)}
        onClose={this.props.handleCancel}
      >
        <Header>Choose Alliances</Header>
        <Modal.Content>
          <Dropdown
            selection
            fluid
            value={this.state.eliminationsSize}
            onChange={this.updateEliminationsSize.bind(this)}
            options={this.state.sizeOptions}
            style={{ marginBottom: "10px" }}
          />
          <Checkbox
            label="Double Elimination"
            checked={this.state.doubleElimination}
            onChange={this.updateDoubleElimination.bind(this)}
            style={{
              marginBottom: "30px"
            }}
          />
          {this.state.teamSelections.map((selection, index) => {
            return (
              <div key={index} style={{ marginBottom: "10px" }}>
                Alliance {index + 1}:
                <Dropdown
                  search
                  selection
                  options={this.props.teamMenuOptions || []}
                  value={selection[0]}
                  onChange={(e, d) => {
                    this.handleSelectedTeamChange(index, 0, d.value);
                  }}
                  style={{ margin: "0 10px" }}
                />
                <Dropdown
                  search
                  selection
                  options={this.props.teamMenuOptions || []}
                  value={selection[1]}
                  onChange={(e, d) => {
                    this.handleSelectedTeamChange(index, 1, d.value);
                  }}
                />
              </div>
            );
          })}
        </Modal.Content>
        <Modal.Actions>
          <Button labelPosition="right" icon="x" onClick={this.props.handleCancel} content="Cancel" />
          <Button
            primary
            labelPosition="right"
            icon="save"
            onClick={() => {
              this.props.handleSubmit(
                this.state.eliminationsSize,
                this.state.doubleElimination,
                this.state.teamSelections
              );
            }}
            content="Start Eliminations"
          />
        </Modal.Actions>
      </Modal>
    );
  }
}

export default StartEliminationsModal;
