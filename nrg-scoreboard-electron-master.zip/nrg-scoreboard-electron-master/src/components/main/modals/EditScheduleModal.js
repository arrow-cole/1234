import React from "react";
import { Header, Dropdown, Button, Modal, Checkbox } from "semantic-ui-react";

class EditScheduleModal extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      matches: []
    };
  }

  // shouldComponentUpdate() {
  //   return this.props.open;
  // }

  componentDidUpdate(oldProps) {
    if (!oldProps.open && this.props.open) {
      this.handleOpen();
    }
  }

  handleOpen() {
    let matches = [];
    // need a deep copy so as not to mutate the original data
    for (let match in this.props.matches) {
      matches.push({
        num: this.props.matches[match].num,
        red1: this.props.matches[match].red1,
        red2: this.props.matches[match].red2,
        blue1: this.props.matches[match].blue1,
        blue2: this.props.matches[match].blue2,
        surrogates: {
          red1: this.props.matches[match].surrogates.red1,
          red2: this.props.matches[match].surrogates.red2,
          blue1: this.props.matches[match].surrogates.blue1,
          blue2: this.props.matches[match].surrogates.blue2
        }
      });
    }

    this.setState({
      matches: matches
    });
  }

  handleSelectedTeamChange(key, index, value) {
    let matches = this.state.matches;
    matches[index][key] = value;
    this.setState({
      matches: matches
    });
  }

  handleSurrogateChange(key, index, value) {
    let matches = this.state.matches;
    matches[index].surrogates[key] = value;
    this.setState({
      matches: matches
    });
  }

  render() {
    return (
      <Modal open={this.props.open} dimmer="inverted" size="fullscreen" onClose={this.props.handleCancel}>
        <Header>Edit Schedule</Header>
        <Modal.Content scrolling>
          <table>
            <thead>
              <tr style={{ textAlign: "center" }}>
                <th>Match</th>
                <th>Red 1</th>
                <th>Red 2</th>
                <th>Blue 1</th>
                <th>Blue 2</th>
                <th>R1 is Surrogate</th>
                <th>R2 is Surrogate</th>
                <th>B1 is Surrogate</th>
                <th>B2 is Surrogate</th>
              </tr>
            </thead>
            <tbody>
              {this.state.matches.map(match => {
                return (
                  <tr key={match.num}>
                    <td>{match.num}</td>
                    <td>
                      <Dropdown
                        search
                        selection
                        options={this.props.teamMenuOptions}
                        value={match.red1}
                        onChange={(e, d) => {
                          this.handleSelectedTeamChange("red1", match.num - 1, d.value);
                        }}
                      />
                    </td>
                    <td>
                      <Dropdown
                        search
                        selection
                        options={this.props.teamMenuOptions}
                        value={match.red2}
                        onChange={(e, d) => {
                          this.handleSelectedTeamChange("red2", match.num - 1, d.value);
                        }}
                      />
                    </td>
                    <td>
                      <Dropdown
                        search
                        selection
                        options={this.props.teamMenuOptions}
                        value={match.blue1}
                        onChange={(e, d) => {
                          this.handleSelectedTeamChange("blue1", match.num - 1, d.value);
                        }}
                      />
                    </td>
                    <td>
                      <Dropdown
                        search
                        selection
                        options={this.props.teamMenuOptions}
                        value={match.blue2}
                        onChange={(e, d) => {
                          this.handleSelectedTeamChange("blue2", match.num - 1, d.value);
                        }}
                      />
                    </td>
                    <td style={{ textAlign: "center" }}>
                      <Checkbox
                        toggle
                        checked={match.surrogates.red1}
                        style={{ textAlign: "center" }}
                        onChange={(e, d) => {
                          this.handleSurrogateChange("red1", match.num - 1, d.checked);
                        }}
                      />
                    </td>
                    <td style={{ textAlign: "center" }}>
                      <Checkbox
                        toggle
                        checked={match.surrogates.red2}
                        style={{ textAlign: "center" }}
                        onChange={(e, d) => {
                          this.handleSurrogateChange("red2", match.num - 1, d.checked);
                        }}
                      />
                    </td>
                    <td style={{ textAlign: "center" }}>
                      <Checkbox
                        toggle
                        checked={match.surrogates.blue1}
                        style={{ textAlign: "center" }}
                        onChange={(e, d) => {
                          this.handleSurrogateChange("blue1", match.num - 1, d.checked);
                        }}
                      />
                    </td>
                    <td style={{ textAlign: "center" }}>
                      <Checkbox
                        toggle
                        checked={match.surrogates.blue2}
                        style={{ textAlign: "center" }}
                        onChange={(e, d) => {
                          this.handleSurrogateChange("blue2", match.num - 1, d.checked);
                        }}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Modal.Content>
        <Modal.Actions>
          <Button labelPosition="right" icon="x" onClick={this.props.handleCancel} content="Cancel" />
          <Button
            primary
            labelPosition="right"
            icon="save"
            onClick={() => {
              this.props.handleSubmit(this.state.matches);
            }}
            content="Save Changes"
          />
        </Modal.Actions>
      </Modal>
    );
  }
}

export default EditScheduleModal;
