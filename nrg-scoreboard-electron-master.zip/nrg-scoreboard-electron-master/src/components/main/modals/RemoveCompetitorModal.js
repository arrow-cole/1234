import React from "react";
import { Modal, Button, Header, Dropdown } from "semantic-ui-react";

class RemoveCompetitorModal extends React.PureComponent {
  constructor(props) {
    super();
    this.state = {
      selectedTeam: "",
      formInvalid: true
    };
  }

  // shouldComponentUpdate() {
  //   return this.props.open;
  // }

  handleSelectedTeamChange(event, data) {
    let replacementsNeeded = [];
    if (data.value) {
      for (let index in this.props.schedule) {
        let match = this.props.schedule[index];
        if (
          !match.scores &&
          (match.red1 === data.value ||
            match.red2 === data.value ||
            match.blue1 === data.value ||
            match.blue2 === data.value)
        ) {
          let filteredTeamArr = this.props.teamMenuOptions.filter(team => {
            return (
              team.key !== data.value &&
              team.key !== match.red1 &&
              team.key !== match.red2 &&
              team.key !== match.blue1 &&
              team.key !== match.blue2
            );
          });
          replacementsNeeded.push({
            num: match.num,
            options: filteredTeamArr,
            selection: filteredTeamArr[Math.floor(Math.random() * filteredTeamArr.length)].key
          });
        }
      }
    }
    this.setState({
      selectedTeam: data.value,
      formInvalid: data.value === null || data.value === "",
      replacementsNeeded: replacementsNeeded
    });
  }

  handleSelectedReplacementChange(num, team) {
    let replacementsNeeded = this.state.replacementsNeeded;
    for (let index in replacementsNeeded) {
      let replacement = replacementsNeeded[index];
      if (replacement.num === num) {
        replacement.selection = team;
      }
    }
    this.setState({
      replacementsNeeded: replacementsNeeded
    });
  }

  handleCancel() {
    this.setState({
      selectedTeam: null
    });
    this.props.handleCancel();
  }

  render() {
    if (this.state.replacementsNeeded) {
      var replacementSelections = this.state.replacementsNeeded.map(replacement => (
        <div key={replacement.num}>
          <span style={{ marginRight: "15px" }}>Match {replacement.num}</span>
          <Dropdown
            search
            selection
            options={replacement.options}
            value={replacement.selection}
            onChange={(e, data) => {
              this.handleSelectedReplacementChange(replacement.num, data.value);
            }}
          />
        </div>
      ));
    }
    return (
      <Modal open={this.props.open} dimmer="inverted" size="tiny" onClose={this.handleCancel.bind(this)}>
        <Header>Remove Competitor</Header>
        <Modal.Content>
          <p>Team to be removed:</p>
          <Dropdown
            search
            selection
            options={this.props.teamMenuOptions}
            value={this.state.selectedTeam}
            onChange={this.handleSelectedTeamChange.bind(this)}
          />
          {this.state.selectedTeam && (
            <div style={{ marginTop: "20px" }}>
              <p>Select who will replace {this.state.selectedTeam} in their remaining matches:</p>
              {replacementSelections}
            </div>
          )}
        </Modal.Content>
        <Modal.Actions>
          <Button labelPosition="right" icon="x" onClick={this.handleCancel.bind(this)} content="Cancel" />
          <Button
            primary
            labelPosition="right"
            icon="trash"
            disabled={this.state.formInvalid}
            onClick={() => {
              this.props.handleSubmit(this.state.selectedTeam, this.state.replacementsNeeded);
              this.setState({
                selectedTeam: "",
                formInvalid: true
              });
            }}
            content="Remove Competitor"
          />
        </Modal.Actions>
      </Modal>
    );
  }
}

export default RemoveCompetitorModal;
