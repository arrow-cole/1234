import React from "react";
import { Modal, Input, Button, Header } from "semantic-ui-react";

class AddLateTeamModal extends React.PureComponent {
  constructor(props) {
    super();
    this.state = {
      teamName: "",
      formInvalid: true
    };
  }

  // shouldComponentUpdate() {
  //   return this.props.open;
  // }

  handleTeamNameChange(event, data) {
    this.setState({
      teamName: data.value,
      formInvalid: data.value === null || data.value === ""
    });
  }

  handleCancel() {
    this.setState({
      teamName: "",
      formInvalid: true
    });
    this.props.handleCancel();
  }

  render() {
    let nameIsDuplicate = this.props.teams[this.state.teamName] ? true : false;
    return (
      <Modal open={this.props.open} dimmer="inverted" size="tiny" onClose={this.handleCancel.bind(this)}>
        <Header>Add Late Competitor</Header>
        <Modal.Content>
          <Input value={this.state.teamName} onChange={this.handleTeamNameChange.bind(this)} placeholder="Team Name" />
          {nameIsDuplicate && (
            <div style={{ marginTop: "20px", color: "red", fontWeight: "bold" }}>
              There is already a team with this name.
            </div>
          )}
          <p style={{ marginTop: "20px" }}>
            <strong>This team will play {this.props.numMatches} matches.</strong> If surrogate matches are needed to
            achieve this number, then they will be used.
          </p>
        </Modal.Content>
        <Modal.Actions>
          <Button labelPosition="right" icon="x" onClick={this.handleCancel.bind(this)} content="Cancel" />
          <Button
            primary
            labelPosition="right"
            icon="save"
            disabled={this.state.formInvalid || nameIsDuplicate}
            onClick={() => {
              this.props.handleSubmit(this.state.teamName);
              this.setState({
                teamName: "",
                formInvalid: true
              });
            }}
            content="Add Team to Schedule"
          />
        </Modal.Actions>
      </Modal>
    );
  }
}

export default AddLateTeamModal;
