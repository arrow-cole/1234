import React from "react";
import { Modal, Header, Input, Button, Divider, Label } from "semantic-ui-react";

class ScoringModal extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      redPoints: "",
      redPenalty: "",
      bluePoints: "",
      bluePenalty: "",
      redRPs: "",
      blueRPs: "",
      redPointsError: false,
      redPenaltyError: false,
      bluePointsError: false,
      bluePenaltyError: false,
      redRPsError: false,
      blueRPsError: false
    };
  }

  // shouldComponentUpdate() {
  //   return this.props.open;
  // }

  handleOpen() {
    /* the props may have changed since the last time this modal was opened, so 
       we should update the internal state. */
    let redPoints = this.props.scores && this.props.scores.red - this.props.scores.bluePenalty;
    let redPenalty = this.props.scores && this.props.scores.redPenalty;
    let bluePoints = this.props.scores && this.props.scores.blue - this.props.scores.redPenalty;
    let bluePenalty = this.props.scores && this.props.scores.bluePenalty;
    let redRPs = this.props.scores && this.props.scores.redRankingPoints;
    let blueRPs = this.props.scores && this.props.scores.blueRankingPoints;
    if (redPoints === undefined) {
      redPoints = "";
    }
    if (redPenalty === undefined) {
      redPenalty = "";
    }
    if (bluePoints === undefined) {
      bluePoints = "";
    }
    if (bluePenalty === undefined) {
      bluePenalty = "";
    }
    if (redRPs === undefined) {
      redRPs = "";
    }
    if (blueRPs === undefined) {
      blueRPs = "";
    }
    this.setState({
      redPoints: redPoints,
      redPenalty: redPenalty,
      bluePoints: bluePoints,
      bluePenalty: bluePenalty,
      redRPs: redRPs,
      blueRPs: blueRPs,
      redPointsError: false,
      redPenaltyError: false,
      bluePointsError: false,
      bluePenaltyError: false,
      redRPsError: false,
      blueRPsError: false,
      noRPs: this.props.match.eliminations !== undefined || !this.props.enableRankingPoints,
    });

    /* call the parent's handler */
    this.props.handleOpen();
  }

  handleChange(event, data) {
    let error = isNaN(Number(data.value));
    let value = data.value;
    if (!error && data.value !== "") {
      value = Number(data.value);
    }

    switch (event.target.name) {
      case "red-points":
        this.setState({
          redPoints: value,
          redPointsError: error
        });
        break;
      case "blue-penalty":
        this.setState({
          bluePenalty: value,
          bluePenaltyError: error
        });
        break;
      case "blue-points":
        this.setState({
          bluePoints: value,
          bluePointsError: error
        });
        break;
      case "red-penalty":
        this.setState({
          redPenalty: value,
          redPenaltyError: error
        });
        break;
      case "red-ranking-points":
        this.setState({
          redRPs: value,
          redRPsError: error
        });
        break;
      case "blue-ranking-points":
        this.setState({
          blueRPs: value,
          blueRPsError: error
        });
        break;
      default:
        break;
    }
  }

  render() {
    return (
      <Modal
        open={this.props.open}
        trigger={this.props.trigger}
        dimmer="inverted"
        size="small"
        onOpen={this.handleOpen.bind(this)}
        onClose={this.props.handleCancel}
      >
        <Header>
          {this.props.match.eliminations ? this.props.match.eliminations.title : "Match " + this.props.match.num} Scoring
        </Header>
        <Modal.Content
          style={{
            display: "grid",
            gridTemplateColumns: "250px 250px",
            gridGap: "30px"
          }}
        >
          <div>
            <Header size="medium" color="red">
              Red Scores
            </Header>
            <Input
              placeholder="Enter a number"
              label={<Label style={{ width: "110px" }} content="Red Points" />}
              labelPosition="left"
              name="red-points"
              value={this.state.redPoints}
              error={this.state.redPointsError}
              fluid
              style={{ marginBottom: "3px" }}
              onChange={this.handleChange.bind(this)}
            />
            <Input
              placeholder="Enter a number"
              label={<Label style={{ width: "110px" }} content="Blue Penalty" />}
              labelPosition="left"
              name="blue-penalty"
              fluid
              value={this.state.bluePenalty}
              error={this.state.bluePenaltyError}
              onChange={this.handleChange.bind(this)}
            />
            <Divider />
            <span style={{ fontWeight: "bold" }}>Total: {this.state.redPoints + this.state.bluePenalty || 0}</span>
            {!this.state.noRPs && (
              <div>
                <Divider />
                <div style={{ marginBottom: "5px" }}>
                  How many <span style={{ fontWeight: "bold" }}>total</span> ranking points did the red alliance earn?
                </div>
                <Input
                  placeholder="Enter number"
                  label="RP"
                  labelPosition="right"
                  name="red-ranking-points"
                  fluid
                  value={this.state.redRPs}
                  error={this.state.redRPsError}
                  onChange={this.handleChange.bind(this)}
                />
              </div>
            )}
          </div>
          <div>
            <Header size="medium" color="blue">
              Blue Scores
            </Header>
            <Input
              placeholder="Enter a number"
              label={<Label style={{ width: "110px" }} content="Blue Points" />}
              labelPosition="left"
              name="blue-points"
              fluid
              value={this.state.bluePoints}
              error={this.state.bluePointsError}
              style={{ marginBottom: "3px" }}
              onChange={this.handleChange.bind(this)}
            />
            <Input
              placeholder="Enter a number"
              label={<Label style={{ width: "110px" }} content="Red Penalty" />}
              labelPosition="left"
              name="red-penalty"
              fluid
              value={this.state.redPenalty}
              error={this.state.redPenaltyError}
              onChange={this.handleChange.bind(this)}
            />
            <Divider />
            <span style={{ fontWeight: "bold" }}>Total: {this.state.bluePoints + this.state.redPenalty || 0}</span>
            {!this.state.noRPs && (
              <div>
                <Divider />
                <div style={{ marginBottom: "5px" }}>
                  How many <span style={{ fontWeight: "bold" }}>total</span> ranking points did the blue alliance earn?
                </div>
                <Input
                  placeholder="Enter number"
                  label="RP"
                  labelPosition="right"
                  name="blue-ranking-points"
                  fluid
                  value={this.state.blueRPs}
                  error={this.state.blueRPsError}
                  onChange={this.handleChange.bind(this)}
                />
              </div>
            )}
          </div>
          {(this.state.redPointsError ||
            this.state.redPenaltyError ||
            this.state.bluePointsError ||
            this.state.bluePenaltyError ||
            this.state.redRPsError ||
            this.state.blueRPsError) && (
            <Header size="small" color="red" style={{ margin: 0, fontStyle: "italic" }}>
              * All fields must be valid numbers
            </Header>
          )}
        </Modal.Content>
        <Modal.Actions>
          <Button color="red" labelPosition="right" icon="x" onClick={this.props.handleCancel} content="Cancel" />
          <Button
            color="green"
            icon="checkmark"
            labelPosition="right"
            content="Save Scores"
            disabled={
              this.state.redPointsError ||
              this.state.redPenaltyError ||
              this.state.bluePointsError ||
              this.state.bluePenaltyError ||
              this.state.redRPsError ||
              this.state.blueRPsError ||
              this.state.redPoints === "" ||
              this.state.redPenalty === "" ||
              this.state.bluePoints === "" ||
              this.state.bluePenalty === "" ||
              (!this.state.noRPs && this.state.redRPs === "") ||
              (!this.state.noRPs && this.state.blueRPs === "")
            }
            onClick={() => {
              let state = this.state;
              if (state.redRPs === "") {
                state.redRPs = 0;
              }
              if (state.blueRPs === "") {
                state.blueRPs = 0;
              }
              this.props.handleSubmit(state);
            }}
          />
        </Modal.Actions>
      </Modal>
    );
  }
}

export default ScoringModal;
