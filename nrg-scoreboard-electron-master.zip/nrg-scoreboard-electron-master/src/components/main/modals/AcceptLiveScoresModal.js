import React from "react";
import { Modal, Header, Input, Button, Divider, Label } from "semantic-ui-react";

class AcceptLiveScoresModal extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      redScores: [],
      blueScores: [],
      redRPs: "",
      blueRPs: "",
      redTotal: 0,
      blueTotal: 0,
      redError: false,
      blueError: false,
      redPenaltyError: false,
      bluePenaltyError: false,
      redRPsError: false,
      blueRPsError: false
    };
  }

  // shouldComponentUpdate() {
  //   return this.props.open;
  // }

  handleOpen() {
    /* the props may have changed since the last time this modal was opened, so 
       we should update the internal state. */
    let redScores = this.props.redFinalScores;
    let blueScores = this.props.blueFinalScores;
    let redRPs = this.props.match && this.props.match.scores && this.props.match.scores.redRankingPoints;
    let blueRPs = this.props.match && this.props.match.scores && this.props.match.scores.blueRankingPoints;
    if (redScores === undefined) {
      redScores = [];
    }
    if (blueScores === undefined) {
      blueScores = [];
    }
    if (redRPs === undefined) {
      redRPs = "";
    }
    if (blueRPs === undefined) {
      blueRPs = "";
    }

    let redTotal = 0;
    let redError = false;
    let redPenalty = (this.props.match.scores && this.props.match.scores.redPenalty) || 0;
    let redPenaltyIndex = -1;
    redScores.forEach((score, index) => {
      if (isNaN(Number(score.value))) {
        redError = true;
      } else if (score.name === "Penalties") {
        redPenalty = score.value;
        redPenaltyIndex = index;
      } else {
        redTotal += Number(score.value);
      }
    });
    if (redPenaltyIndex !== -1) {
      redScores.splice(redPenaltyIndex, 1);
    }

    let blueTotal = 0;
    let blueError = false;
    let bluePenalty = (this.props.match.scores && this.props.match.scores.bluePenalty) || 0;
    let bluePenaltyIndex = -1;
    blueScores.forEach((score, index) => {
      if (isNaN(Number(score.value))) {
        blueError = true;
      } else if (score.name === "Penalties") {
        bluePenalty = score.value;
        bluePenaltyIndex = index;
      } else {
        blueTotal += Number(score.value);
      }
    });
    if (bluePenaltyIndex !== -1) {
      blueScores.splice(bluePenaltyIndex, 1);
    }

    this.setState({
      redScores: redScores,
      blueScores: blueScores,
      redPenalty: redPenalty,
      bluePenalty: bluePenalty,
      redRPs: redRPs,
      blueRPs: blueRPs,
      redTotal: redTotal,
      blueTotal: blueTotal,
      redPenaltyError: isNaN(redPenalty),
      bluePenaltyError: isNaN(bluePenalty),
      redError: redError,
      blueError: blueError,
      redRPsError: false,
      blueRPsError: false,
      noRPs: this.props.match.eliminations !== undefined || !this.props.enableRankingPoints,
    });

    /* call the parent's handler */
    this.props.handleOpen();
  }

  handleChange(team, index, value) {
    let scores = this.state[team + "Scores"];
    scores[index].value = value;

    let total = 0;
    let error = false;
    scores.forEach(score => {
      if (isNaN(Number(score.value))) {
        error = true;
      } else {
        total += Number(score.value);
      }
    });

    if (team === "red") {
      this.setState({
        redScores: scores,
        redTotal: total,
        redError: error
      });
    } else {
      this.setState({
        blueScores: scores,
        blueTotal: total,
        blueError: error
      });
    }
  }

  handlePenaltyOrRPChange(event, data) {
    let error = isNaN(Number(data.value));
    let value = data.value;
    if (!error && data.value !== "") {
      value = Number(data.value);
    }

    switch (event.target.name) {
      case "red-ranking-points":
        this.setState({
          redRPs: value,
          redRPsError: error
        });
        break;
      case "blue-ranking-points":
        this.setState({
          blueRPs: value,
          blueRPsError: error
        });
        break;
      case "red-penalty":
        this.setState({
          redPenalty: value,
          redPenaltyError: error
        });
        break;
      case "blue-penalty":
        this.setState({
          bluePenalty: value,
          bluePenaltyError: error
        });
        break;
      default:
        break;
    }
  }

  render() {
    return (
      <Modal
        open={this.props.open}
        trigger={this.props.trigger}
        dimmer="inverted"
        size="small"
        onOpen={this.handleOpen.bind(this)}
        onClose={this.props.handleCancel}
      >
        <Header>
          {this.props.match.eliminations ? this.props.match.eliminations.title : "Match " + this.props.match.num}{" "}
          Scoring
        </Header>
        <Modal.Content
          scrolling
          style={{
            display: "grid",
            gridTemplateColumns: "250px 250px",
            gridGap: "30px"
          }}
        >
          <div>
            <Header size="medium" color="red">
              Red Scores
            </Header>
            {this.state.redScores.map((score, index) => (
              <Input
                key={index}
                placeholder="Enter a number"
                label={<Label style={{ width: "110px" }} content={score.name} />}
                labelPosition="left"
                name={score.name}
                fluid
                value={score.value}
                error={isNaN(Number(score.value))}
                style={{ marginBottom: "3px" }}
                onChange={(e, d) => {
                  this.handleChange("red", index, d.value);
                }}
              />
            ))}
            <Input
              placeholder="Enter a number"
              label={<Label style={{ width: "110px" }} content="Blue Penalty" />}
              labelPosition="left"
              name="blue-penalty"
              fluid
              value={this.state.bluePenalty}
              error={this.state.bluePenaltyError}
              style={{ marginBottom: "3px" }}
              onChange={this.handlePenaltyOrRPChange.bind(this)}
            />
            <Divider />
            <span style={{ fontWeight: "bold" }}>Total: {this.state.redTotal + this.state.bluePenalty}</span>
            {!this.state.noRPs && (
              <div>
                <Divider />
                <div style={{ marginBottom: "5px" }}>
                  How many <span style={{ fontWeight: "bold" }}>total</span> ranking points did the red alliance earn?
                </div>
                <Input
                  placeholder="Enter number"
                  label="RP"
                  labelPosition="right"
                  name="red-ranking-points"
                  fluid
                  value={this.state.redRPs}
                  error={this.state.redRPsError}
                  onChange={this.handlePenaltyOrRPChange.bind(this)}
                />
              </div>
            )}
          </div>
          <div>
            <Header size="medium" color="blue">
              Blue Scores
            </Header>
            {this.state.blueScores.map((score, index) => (
              <Input
                key={index}
                placeholder="Enter a number"
                label={<Label style={{ width: "110px" }} content={score.name} />}
                labelPosition="left"
                name={score.name}
                fluid
                value={score.value}
                error={isNaN(Number(score.value))}
                style={{ marginBottom: "3px" }}
                onChange={(e, d) => {
                  this.handleChange("blue", index, d.value);
                }}
              />
            ))}
            <Input
              placeholder="Enter a number"
              label={<Label style={{ width: "110px" }} content="Red Penalty" />}
              labelPosition="left"
              name="red-penalty"
              fluid
              value={this.state.redPenalty}
              error={this.state.redPenaltyError}
              style={{ marginBottom: "3px" }}
              onChange={this.handlePenaltyOrRPChange.bind(this)}
            />
            <Divider />
            <span style={{ fontWeight: "bold" }}>Total: {this.state.blueTotal + this.state.redPenalty}</span>
            {!this.state.noRPs && (
              <div>
                <Divider />
                <div style={{ marginBottom: "5px" }}>
                  How many <span style={{ fontWeight: "bold" }}>total</span> ranking points did the blue alliance earn?
                </div>
                <Input
                  placeholder="Enter number"
                  label="RP"
                  labelPosition="right"
                  name="blue-ranking-points"
                  fluid
                  value={this.state.blueRPs}
                  error={this.state.blueRPsError}
                  onChange={this.handlePenaltyOrRPChange.bind(this)}
                />
              </div>
            )}
          </div>
          {(this.state.redError ||
            this.state.blueError ||
            this.state.redPenaltyError ||
            this.state.bluePenaltyError ||
            this.state.redRPsError ||
            this.state.blueRPsError) && (
            <Header size="small" color="red" style={{ margin: 0, fontStyle: "italic" }}>
              * All fields must be valid numbers
            </Header>
          )}
        </Modal.Content>
        <Modal.Actions>
          <Button color="red" labelPosition="right" icon="x" onClick={this.props.handleCancel} content="Cancel" />
          <Button
            color="green"
            icon="checkmark"
            labelPosition="right"
            content="Save Scores"
            disabled={
              this.state.redError ||
              this.state.blueError ||
              this.state.redPenaltyError ||
              this.state.bluePenaltyError ||
              this.state.redRPsError ||
              this.state.blueRPsError ||
              (!this.state.noRPs && this.state.redRPs === "") ||
              (!this.state.noRPs && this.state.blueRPs === "")
            }
            onClick={() => {
              let liveScores = {
                redPoints: this.state.redTotal,
                bluePoints: this.state.blueTotal,
                redPenalty: this.state.redPenalty,
                bluePenalty: this.state.bluePenalty,
                redRPs: this.state.redRPs,
                blueRPs: this.state.blueRPs,
                liveScoreBreakdown: {
                  red: this.state.redScores,
                  blue: this.state.blueScores
                }
              };
              if (liveScores.redRPs === "") {
                liveScores.redRPs = 0;
              }
              if (liveScores.blueRPs === "") {
                liveScores.blueRPs = 0;
              }
              this.props.handleSubmit(liveScores);
            }}
          />
        </Modal.Actions>
      </Modal>
    );
  }
}

export default AcceptLiveScoresModal;
