import React from "react";
import { Modal, Input, Button, Header, Dropdown } from "semantic-ui-react";

class EditTeamNameModal extends React.PureComponent {
  constructor(props) {
    super();
    this.state = {
      selectedTeam: "",
      renameTo: "",
      formInvalid: true
    };
  }

  // shouldComponentUpdate() {
  //   return this.props.open;
  // }

  handleRenameToChange(event, data) {
    this.setState({
      renameTo: data.value,
      formInvalid:
        data.value === null || data.value === "" || this.state.selectedTeam === null || this.state.selectedTeam === ""
    });
  }

  handleSelectedTeamChange(event, data) {
    this.setState({
      selectedTeam: data.value,
      formInvalid:
        data.value === null || data.value === "" || this.state.renameTo === null || this.state.renameTo === ""
    });
  }

  handleCancel() {
    this.setState({
      selectedTeam: null,
      renameTo: "",
      formInvalid: true
    });
    this.props.handleCancel();
  }

  render() {
    let nameIsDuplicate = false;
    (this.props.teamMenuOptions).forEach(team => {
      if (team.key === this.state.renameTo) {
        nameIsDuplicate = true;
      }
    });
    return (
      <Modal open={this.props.open} dimmer="inverted" size="tiny" onClose={this.handleCancel.bind(this)}>
        <Header>Edit Team Name</Header>
        <Modal.Content>
          Rename{" "}
          <Dropdown
            search
            selection
            options={this.props.teamMenuOptions}
            value={this.state.selectedTeam}
            onChange={this.handleSelectedTeamChange.bind(this)}
          />{" "}
          to <Input value={this.state.renameTo} onChange={this.handleRenameToChange.bind(this)} />
          {nameIsDuplicate && (
            <div style={{ marginTop: "20px", color: "red", fontWeight: "bold" }}>
              There is already a team with this name.
            </div>
          )}
        </Modal.Content>
        <Modal.Actions>
          <Button labelPosition="right" icon="x" onClick={this.handleCancel.bind(this)} content="Cancel" />
          <Button
            primary
            labelPosition="right"
            icon="save"
            disabled={this.state.formInvalid || nameIsDuplicate}
            onClick={() => {
              this.props.handleSubmit(this.state.selectedTeam, this.state.renameTo);
              this.setState({
                selectedTeam: "",
                renameTo: "",
                formInvalid: true
              });
            }}
            content="Rename Team"
          />
        </Modal.Actions>
      </Modal>
    );
  }
}

export default EditTeamNameModal;
