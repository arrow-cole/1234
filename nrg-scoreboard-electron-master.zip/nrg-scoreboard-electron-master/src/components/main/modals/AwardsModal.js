import React from "react";
import { Input, Button, Modal, Header } from "semantic-ui-react";

function AwardsModal(props) {
  return (
    <Modal open={props.open} dimmer="inverted" size="large" onClose={props.handleCancel}>
      <Header>Awards</Header>
      <Modal.Content>
        <Button
          toggle
          active={props.activeAward === "nrg-logo-only"}
          onClick={() => {
            props.handleSetActiveAward("nrg-logo-only");
          }}
        >
          Show NRG Logo Only
        </Button>
        <Button onClick={props.handleShowAwardWinner}>Reveal Winner</Button>
        <table>
          <thead>
            <tr>
              <th>Award</th>
              <th>Recipient</th>
            </tr>
          </thead>
          <tbody>
            {props.awards.map((award, index) => (
              <tr key={index}>
                <td>
                  <Input
                    value={award.name}
                    placeholder="Enter Award Name"
                    onChange={(event, data) => {
                      let awards = props.awards;
                      awards[index].name = data.value;
                      props.handleChangeAwards(awards);
                    }}
                  />
                </td>
                <td>
                  <Input
                    value={award.team}
                    placeholder="Enter Team Name"
                    onChange={(event, data) => {
                      let awards = props.awards;
                      awards[index].team = data.value;
                      props.handleChangeAwards(awards);
                    }}
                  />
                </td>
                <td>
                  <Button
                    toggle
                    active={props.activeAward === index}
                    onClick={() => {
                      props.handleSetActiveAward(index);
                    }}
                  >
                    Show On Screen
                  </Button>
                </td>
                <td>
                  <Button
                    onClick={() => {
                      let awards = props.awards;
                      awards.splice(index, 1);
                      props.handleChangeAwards(awards);
                    }}
                  >
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <Button
          style={{ marginTop: "15px" }}
          onClick={() => {
            let awards = props.awards;
            awards.push({
              name: "",
              team: ""
            });
            props.handleChangeAwards(awards);
          }}
        >
          Add Another Award
        </Button>
      </Modal.Content>
      <Modal.Actions>
        <Button labelPosition="right" icon="x" onClick={props.handleCancel} content="Close Awards Settings" />
      </Modal.Actions>
    </Modal>
  );
}

export default AwardsModal;
