import React from "react";
import { Modal, Input, Button, Header } from "semantic-ui-react";

class ProjectorOverrideModal extends React.PureComponent {
  constructor(props) {
    super();
    this.state = {
      header: "",
      red1: "",
      red2: "",
      blue1: "",
      blue2: ""
    };
  }

  // shouldComponentUpdate() {
  //   return this.props.open;
  // }

  handleChange(event, data) {
    let value = data.value;
    switch (event.target.name) {
      case "header":
        this.setState({
          header: value
        });
        break;
      case "red1":
        this.setState({
          red1: value
        });
        break;
      case "red2":
        this.setState({
          red2: value
        });
        break;
      case "blue1":
        this.setState({
          blue1: value
        });
        break;
      case "blue2":
        this.setState({
          blue2: value
        });
        break;
      default:
        break;
    }
  }

  render() {
    return (
      <Modal open={this.props.open} dimmer="inverted" size="small" onClose={this.props.handleCancel}>
        <Header>Manually Set Displayed Projector Data</Header>
        <Modal.Content>
          <table>
            <tr>
              <td>Header: </td>
              <td>
                <Input
                  name="header"
                  placeholder="Header"
                  value={this.state.header}
                  onChange={this.handleChange.bind(this)}
                />
              </td>
            </tr>
            <tr>
              <td>Red 1: </td>
              <td>
                <Input
                  name="red1"
                  placeholder="Red 1"
                  value={this.state.red1}
                  onChange={this.handleChange.bind(this)}
                />{" "}
              </td>
            </tr>
            <tr>
              <td>Red 2: </td>
              <td>
                <Input
                  name="red2"
                  placeholder="Red 2"
                  value={this.state.red2}
                  onChange={this.handleChange.bind(this)}
                />
              </td>
            </tr>
            <tr>
              <td>Blue 1: </td>
              <td>
                <Input
                  name="blue1"
                  placeholder="Blue 1"
                  value={this.state.blue1}
                  onChange={this.handleChange.bind(this)}
                />
              </td>
            </tr>
            <tr>
              <td>Blue 2: </td>
              <td>
                <Input
                  name="blue2"
                  placeholder="Blue 2"
                  value={this.state.blue2}
                  onChange={this.handleChange.bind(this)}
                />
              </td>
            </tr>
          </table>
        </Modal.Content>
        <Modal.Actions>
          <Button labelPosition="right" icon="x" onClick={this.props.handleCancel} content="Cancel" />
          <Button
            primary
            labelPosition="right"
            icon="save"
            onClick={() => {
              this.props.handleSubmit({
                header: this.state.header,
                red1: this.state.red1,
                red2: this.state.red2,
                blue1: this.state.blue1,
                blue2: this.state.blue2
              });
            }}
            content="Enable Override"
          />
        </Modal.Actions>
      </Modal>
    );
  }
}

export default ProjectorOverrideModal;
