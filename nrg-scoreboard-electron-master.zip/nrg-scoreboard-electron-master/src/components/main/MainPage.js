import React from "react";

import FieldControls from "./FieldControls";
import FieldStatus from "./FieldStatus";
import EliminationControls from "./EliminationControls";
import ProjectorControls from "./ProjectorControls";
import MatchSchedule from "./MatchSchedule";
import ProjectorOverrideModal from "./modals/ProjectorOverrideModal";
import AddMoreMatchesModal from "./modals/AddMoreMatchesModal";
import EditTeamNameModal from "./modals/EditTeamNameModal";
import AddLateTeamModal from "./modals/AddLateTeamModal";
import RemoveTeamModal from "./modals/RemoveCompetitorModal";
import EditScheduleModal from "./modals/EditScheduleModal";
import AwardsModal from "./modals/AwardsModal";

class MainPage extends React.Component {
  render() {
    return (
      <div className="app-container">
        <div className="main-container">
          <div className="controls-container">
            <FieldControls
              match={this.props.state.matches[this.props.state.currentMatch - 1]}
              field={this.props.state.currentField}
              matchRunning={this.props.state.matchRunning}
              timeRemaining={this.props.state.timeRemaining}
              opModes={this.props.state.opModes}
              numMatches={this.props.state.matches.length}
              liveScoreEnabled={this.props.state.liveScore.enabled}
              hasRedFinalScores={this.props.state.liveScore.finalScores.red !== null}
              hasBlueFinalScores={this.props.state.liveScore.finalScores.blue !== null}
              redFinalScores={this.props.state.liveScore.finalScores.red}
              blueFinalScores={this.props.state.liveScore.finalScores.blue}
              handleIncDecMatch={this.props.handleIncDecMatch}
              handleSetField={this.props.handleSetField}
              handleStartStopMatch={this.props.handleStartStopMatch}
              handleChangeOpModes={this.props.handleChangeOpModes}
              handleSubmitScores={this.props.handleSubmitScores}
              enableRankingPoints={this.props.state.enableRankingPoints}
            />
            <div style={{ display: "flex", flexDirection: "row" }}>
              <FieldStatus status={this.props.state.status} />
              <EliminationControls
                sortedRankings={this.props.state.sortedRankings}
                handleStartEliminations={this.props.handleStartEliminations}
                handleOverrideEliminationAdvancements={this.props.handleOverrideEliminationAdvancements}
                isStarted={this.props.state.eliminations}
                matches={this.props.state.matches}
                teamMenuOptions={this.props.state.teamMenuOptions}
                currentMatch={this.props.state.currentMatch}
                enableRankingPoints={this.props.state.enableRankingPoints}
              />
            </div>
            <ProjectorControls
              projectorMode={this.props.state.projectorMode}
              eliminations={this.props.state.eliminations}
              handleChangeProjectorMode={this.props.handleChangeProjectorMode}
              scoresAvailable={this.props.state.matches[this.props.state.currentMatch - 1].scores !== undefined}
              nextMatchPreviewAvailable={this.props.state.currentMatch < this.props.state.matches.length}
              rankingsScroll={this.props.state.rankingsScroll}
              handleRankingsScrollChange={this.props.handleRankingsScrollChange}
              handleOpenAwardsSettings={this.props.handleOpenAwardsSettings}
            />
          </div>
          <MatchSchedule
            currentMatch={this.props.state.currentMatch}
            handleSubmitScores={this.props.handleSubmitScores}
            matches={this.props.state.matches}
            handleIncDecMatch={this.props.handleIncDecMatch}
            enableRankingPoints={this.props.state.enableRankingPoints}
          />
        </div>
        <div className="status-bar">This is the status bar</div>
        <ProjectorOverrideModal
          open={this.props.state.projectorOverride.modalOpen}
          handleSubmit={this.props.handleOverrideProjectorSubmit}
          handleCancel={this.props.handleOverrideProjectorCancel}
        />
        <AddMoreMatchesModal
          open={this.props.state.addMoreMatchesModalOpen}
          handleSubmit={this.props.handleAddMoreMatchesSubmit}
          handleCancel={this.props.handleAddMoreMatchesCancel}
          teamMenuOptions={this.props.state.teamMenuOptions}
          numMatches={this.props.state.matches.length}
        />
        <EditTeamNameModal
          open={this.props.state.editTeamNameModalOpen}
          handleSubmit={this.props.handleEditTeamNameSubmit}
          handleCancel={this.props.handleEditTeamNameCancel}
          teamMenuOptions={this.props.state.teamMenuOptions}
        />
        <AddLateTeamModal
          open={this.props.state.addLateCompetitorModalOpen}
          handleSubmit={this.props.handleAddLateTeamSubmit}
          handleCancel={this.props.handleAddLateTeamCancel}
          teams={this.props.state.teams}
          numMatches={this.props.state.numMatchesPerTeam}
        />
        <RemoveTeamModal
          open={this.props.state.removeCompetitorModalOpen}
          handleSubmit={this.props.handleRemoveTeamSubmit}
          handleCancel={this.props.handleRemoveTeamCancel}
          schedule={this.props.state.matches}
          teamMenuOptions={this.props.state.teamMenuOptions}
        />
        <EditScheduleModal
          open={this.props.state.editScheduleModalOpen}
          matches={this.props.state.matches}
          teamMenuOptions={this.props.state.teamMenuOptions}
          handleCancel={this.props.handleEditScheduleModalCancel}
          handleSubmit={this.props.handleEditScheduleModalSubmit}
        />
        <AwardsModal 
          open={this.props.state.awardsModalOpen}
          awards={this.props.state.awards}
          activeAward={this.props.state.activeAward}
          handleCancel={this.props.handleAwardsModalCancel}
          handleChangeAwards={this.props.handleChangeAwards}
          handleSetActiveAward={this.props.handleSetActiveAward}
          handleShowAwardWinner={this.props.handleShowAwardWinner}
        />
      </div>
    );
  }
}

export default MainPage;
