import React from "react";
const electron = window.require("electron");

class TestPage extends React.Component {
  constructor(props) {
    super(props);

    this.increaseNumber.bind(this);

    electron.ipcRenderer.on("test", () => {
      this.increaseNumber(null, null);
    });
    electron.ipcRenderer.on("text", (o, e) => {
      this.setState({ text: e.text });
    });

    this.state = {
      number: 0,
      text: ""
    };
  }

  increaseNumber(event, arg) {
    this.setState({
      number: this.state.number + 1
    });
  }

  render() {
    return (
      <div>
        <div>
          <h1>This is a test</h1>
        </div>
        <div style={{ fontSize: 50, margin: "auto", textAlign: "center" }}>
          {this.state.number}
        </div>
        <div>{this.state.text}</div>
      </div>
    );
  }
}

export default TestPage;
