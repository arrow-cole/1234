import React from "react";
import LogoOnly from "./LogoOnly";
import MatchDetail from "./MatchDetail";
import MatchDetailLiveScore from "./MatchDetailLiveScore";
import MatchScores from "./MatchScores";
import PreMatchScreen from "./PreMatchScreen";
import Awards from "./Awards";
import EliminationBracket from "./EliminationBracket";
import Rankings from "./Rankings";
import "../../css/projector.css";

const electron = window.require("electron");

class Projector extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentScreen: "nrg-logo-only",
      controllerState: {},
    };
    electron.ipcRenderer.on("update-projector", (e, state) => {
      this.setState({
        currentScreen: state.projectorMode,
        controllerState: state,
      });
    });
  }
  render() {
    let matches = this.state.controllerState.matches;
    let currentMatchNum = this.state.controllerState.currentMatch;
    let match = {
      num: 0,
      red1: "Red 1",
      red2: "Red 2",
      blue1: "Blue 1",
      blue2: "Blue 2",
    };
    let nextMatch = match;
    if (matches != null && matches.length > currentMatchNum - 1) {
      match = matches[currentMatchNum - 1];
    }
    if (matches != null && matches.length > currentMatchNum) {
      nextMatch = matches[currentMatchNum];
    }
    if (match.scores === undefined) {
      match.scores = {
        red: 0,
        blue: 0,
        redPenalty: 0,
        bluePenalty: 0,
        redRankingPoints: 0,
        blueRankingPoints: 0,
      };
    }
    let liveScore = this.state.controllerState.liveScore;

    return (
      <div
        className="projector"
        style={{
          width: "100vw",
          height: "100vh",
          lineHeight: "normal",
          background: "#202020",
          fontSize: "1.865vh",
          overflow: "hidden",
        }}
      >
        <LogoOnly opacity={this.state.currentScreen === "nrg-logo-only" ? 1 : 0} />
        <MatchDetail
          opacity={this.state.currentScreen === "match-details" && !liveScore.enabled ? 1 : 0}
          timeRemaining={this.state.controllerState.timeRemaining}
          matchDuration={this.state.controllerState.matchDuration}
          match={match}
          field={this.state.controllerState.currentField}
          overrideInfo={this.state.controllerState.projectorOverride}
          hotColor={this.state.controllerState.currentHotColor}
        />
        <MatchDetailLiveScore
          opacity={this.state.currentScreen === "match-details" && liveScore.enabled ? 1 : 0}
          timeRemaining={this.state.controllerState.timeRemaining}
          matchDuration={this.state.controllerState.matchDuration}
          match={match}
          redScore={liveScore && liveScore.liveScores.redPoints + liveScore.liveScores.bluePenalty}
          blueScore={liveScore && liveScore.liveScores.bluePoints + liveScore.liveScores.redPenalty}
          field={this.state.controllerState.currentField}
          overrideInfo={this.state.controllerState.projectorOverride}
          hotColor={this.state.controllerState.currentHotColor}
        />
        <MatchScores
          opacity={this.state.currentScreen === "match-scores" ? 1 : 0}
          match={match}
          teams={this.state.controllerState.teams}
          highScore={this.state.controllerState.highScore}
          highScoreMatch={this.state.controllerState.highScoreMatch}
          overrideInfo={this.state.controllerState.projectorOverride}
          enableRankingPoints={this.state.controllerState.enableRankingPoints}
        />
        <PreMatchScreen
          opacity={this.state.currentScreen.startsWith("prematch-") ? 1 : 0}
          match={this.state.currentScreen.endsWith("next") ? nextMatch : match}
          rankings={this.state.controllerState.sortedRankings}
          overrideInfo={this.state.controllerState.projectorOverride}
          enableRankingPoints={this.state.controllerState.enableRankingPoints}
        />
        <EliminationBracket
          opacity={this.state.currentScreen.startsWith("elimination-bracket") ? 1 : 0}
          matches={this.state.controllerState.matches}
          doubleEliminations={this.state.controllerState.doubleEliminations}
          nextMatch={this.state.currentScreen.endsWith("next") ? nextMatch.num : match.num}
        />
        <Rankings
          opacity={this.state.currentScreen === "rankings" ? 1 : 0}
          rankings={this.state.controllerState.sortedRankings}
          scroll={this.state.controllerState.rankingsScroll}
          enableRankingPoints={this.state.controllerState.enableRankingPoints}
        />
        <Awards
          opacity={this.state.currentScreen === "awards" ? 1 : 0}
          awards={this.state.controllerState.awards}
          activeAward={this.state.controllerState.activeAward}
          showWinner={this.state.controllerState.showAwardWinner}
        />
      </div>
    );
  }
}

export default Projector;
