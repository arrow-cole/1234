import React from "react";
import { animateScroll as scroll } from "react-scroll";

class Rankings extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      position: "top"
    };
  }

  componentDidUpdate(oldProps) {
    if (!oldProps.scroll && this.props.scroll) {
      this.startScrolling();
    } else if (oldProps.scroll && !this.props.scroll) {
      this.stopScrolling();
    }
  }

  componentDidMount() {
    if (this.props.scroll) {
      this.startScrolling();
    }
  }

  startScrolling() {
    scroll.scrollToTop({
      containerId: "rankings-full",
      smooth: "linear",
      duration: 500
    });
    this.setState({
      position: "top"
    });
    this.setState({
      scrollIntervalId: setInterval(() => {
        this.scroll();
      }, 15000)
    });
  }

  stopScrolling() {
    clearInterval(this.state.scrollIntervalId);
    setTimeout(
      () => {
        scroll.scrollToTop({
          containerId: "rankings-full",
          smooth: "linear",
          duration: 3000
        });
        this.setState({
          position: "top"
        });
      },
      this.state.position === "bottom" ? 10000 : 0
    );
  }

  scroll() {
    if (this.state.position === "top") {
      scroll.scrollToBottom({
        containerId: "rankings-full",
        smooth: "linear",
        duration: 10000
      });
      this.setState({
        position: "bottom"
      });
    } else {
      scroll.scrollToTop({
        containerId: "rankings-full",
        smooth: "linear",
        duration: 10000
      });
      this.setState({
        position: "top"
      });
    }
  }

  render() {
    return (
      <div className="projector-screen" style={{ opacity: this.props.opacity }}>
        <div className="prematch-rankings" style={{ top: "0" }}>
          <div
            id="rankings-full"
            className="no-scroll-bar"
            style={{
              fontSize: "1.5em",
              textAlign: "left",
              fontWeight: "normal",
              width: "100%",
              height: "100%",
              overflow: "auto"
            }}
          >
            <table className="rankings-table" cellSpacing="0">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Team</th>
                  {this.props.enableRankingPoints && <th>Avg. RP</th>}
                  <th>Record</th>
                  <th>Total Penalty (Committed)</th>
                </tr>
              </thead>
              <tbody>
                {this.props.rankings &&
                  this.props.rankings.map(team => (
                    <tr key={team.name}>
                      <td>{String(team.rank).padStart(2, "0")}</td>
                      <td>{team.name}</td>
                      {this.props.enableRankingPoints && (
                        <td>{(team.totalRankingPoints / Object.values(team.scoreHistory).length || 0).toFixed(2)}</td>
                      )}
                      <td>
                        ({team.totalWins || 0}-{team.totalLosses || 0}-{team.totalTies || 0})
                      </td>
                      <td>{team.totalPenaltyPoints || 0}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}

export default Rankings;
