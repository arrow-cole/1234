import React from "react";
import code_red_logo from "../../images/code_red_logo.png";
import logo from "../../images/logo.png";

function Awards(props) {
  return (
    <div
      className="projector-screen"
      style={{
        opacity: props.opacity
      }}
    >
      <img
        style={{
          width: "18em",
          height: "18em",
          objectFit: "contain",
          position: "absolute",
          bottom: "0",
          left: "0"
        }}
        src={logo}
        alt="Logo"
      />
      <img
        style={{
          width: "18em",
          height: "18em",
          objectFit: "contain",
          position: "absolute",
          bottom: "-1em",
          right: "1em"
        }}
        src={code_red_logo}
        alt="CodeRedLogo"
      />
      <div
        style={{
          fontSize: "6em",
          textAlign: "center"
        }}
      >
        {props.awards && props.awards[props.activeAward] && (
          <div>
            <div
              style={{
                color: "lightgray",
                position: "absolute",
                top: "3%",
                left: "0",
                right: "0"
              }}
            >
              {props.awards[props.activeAward].name}
            </div>
            {props.showWinner && (
              <div style={{ position: "absolute", top: "45%", left: "0", right: "0" }}>
                {props.awards[props.activeAward].team}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default Awards;
