import React from "react";
import logo from "../../images/logo.png";

function LogoOnly(props) {
  return (
    <div className="projector-screen" style={{ opacity: props.opacity }}>
      <img
        style={{
          width: "100%",
          height: "100%",
          objectFit: "contain"
        }}
        src={logo}
        alt="Logo"
      />
    </div>
  );
}

export default LogoOnly;
