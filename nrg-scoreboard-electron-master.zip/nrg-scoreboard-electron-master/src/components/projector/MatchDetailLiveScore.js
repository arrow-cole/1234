import React from "react";

function MatchDetailLiveScore(props) {
  let minutes = Math.trunc(props.timeRemaining / 60);
  let time = minutes + ":" + ("000" + (props.timeRemaining - 60 * minutes)).slice(-2);
  let percent = 100 * (1 - props.timeRemaining / props.matchDuration);

  let overrideEnabled = props.overrideInfo && props.overrideInfo.enabled;
  let header = overrideEnabled
    ? props.overrideInfo.header
    : props.match.eliminations
    ? props.match.eliminations.title
    : "Qualification Match " + props.match.num;
  let red1 = overrideEnabled ? props.overrideInfo.red1 : props.match.red1;
  let red2 = overrideEnabled ? props.overrideInfo.red2 : props.match.red2;
  let blue1 = overrideEnabled ? props.overrideInfo.blue1 : props.match.blue1;
  let blue2 = overrideEnabled ? props.overrideInfo.blue2 : props.match.blue2;

  if (!overrideEnabled && props.match.surrogates && props.match.surrogates.red1) red1 += " (Surrogate)";
  if (!overrideEnabled && props.match.surrogates && props.match.surrogates.red2) red2 += " (Surrogate)";
  if (!overrideEnabled && props.match.surrogates && props.match.surrogates.blue1) blue1 += " (Surrogate)";
  if (!overrideEnabled && props.match.surrogates && props.match.surrogates.blue2) blue2 += " (Surrogate)";

  const progressColor = props.hotColor === "none" ? "#21ba45" : props.hotColor;

  return (
    <div className="projector-screen" style={{ opacity: props.opacity }}>
      <div className="header">
        <span>{header}</span>
        <span>Field {props.field}</span>
      </div>
      <div className="versus-container">
        <div className="versus-teams-container red">
          <div className="versus-team red dull">{red1}</div>
          <div className="versus-team red dull">{red2}</div>
          <div className="versus-score">{props.redScore}</div>
        </div>
        <div className="versus">vs</div>
        <div className="versus-teams-container blue">
          <div className="versus-team blue dull">{blue1}</div>
          <div className="versus-team blue dull">{blue2}</div>
          <div className="versus-score">{props.blueScore}</div>
        </div>
      </div>
      <div className="remaining-time">REMAINING TIME:</div>
      <div className="time">
        <div style={{ zIndex: "1" }}>{time}</div>
        <div
          className="progress"
          style={{
            background: progressColor,
            width: percent + "%",
          }}
        />
      </div>
    </div>
  );
}

export default MatchDetailLiveScore;
