import React from "react";

class MatchScores extends React.Component {
  render() {
    let overrideEnabled = this.props.overrideInfo && this.props.overrideInfo.enabled;

    var red1Ranking = "";
    var red2Ranking = "";
    var blue1Ranking = "";
    var blue2Ranking = "";
    if (
      !overrideEnabled &&
      this.props.teams &&
      this.props.teams[this.props.match.red1] &&
      this.props.teams[this.props.match.red2] &&
      this.props.teams[this.props.match.blue1] &&
      this.props.teams[this.props.match.blue2]
    ) {
      red1Ranking = "Rank " + this.props.teams[this.props.match.red1].rank;
      red2Ranking = "Rank " + this.props.teams[this.props.match.red2].rank;
      blue1Ranking = "Rank " + this.props.teams[this.props.match.blue1].rank;
      blue2Ranking = "Rank " + this.props.teams[this.props.match.blue2].rank;
    }

    let header = overrideEnabled
      ? this.props.overrideInfo.header
      : this.props.match.eliminations
      ? this.props.match.eliminations.title
      : "Qualification Match " + this.props.match.num;
    let red1 = overrideEnabled ? this.props.overrideInfo.red1 : this.props.match.red1;
    let red2 = overrideEnabled ? this.props.overrideInfo.red2 : this.props.match.red2;
    let blue1 = overrideEnabled ? this.props.overrideInfo.blue1 : this.props.match.blue1;
    let blue2 = overrideEnabled ? this.props.overrideInfo.blue2 : this.props.match.blue2;

    if (!overrideEnabled && this.props.match.surrogates && this.props.match.surrogates.red1) red1 += " (Surrogate)";
    if (!overrideEnabled && this.props.match.surrogates && this.props.match.surrogates.red2) red2 += " (Surrogate)";
    if (!overrideEnabled && this.props.match.surrogates && this.props.match.surrogates.blue1) blue1 += " (Surrogate)";
    if (!overrideEnabled && this.props.match.surrogates && this.props.match.surrogates.blue2) blue2 += " (Surrogate)";

    let redWins = 0;
    let blueWins = 0;
    if (this.props.match.eliminations) {
      let calculateWinner = match => {
        if (match.scores.red > match.scores.blue) {
          redWins++;
        } else if (match.scores.blue > match.scores.red) {
          blueWins++;
        }
      };
      calculateWinner(this.props.match);
      if (this.props.match.eliminations.dependant && this.props.match.eliminations.dependant.scores) {
        calculateWinner(this.props.match.eliminations.dependant);
      }
      if (this.props.match.eliminations.tiebreaker && this.props.match.eliminations.tiebreaker.scores) {
        calculateWinner(this.props.match.eliminations.tiebreaker);
      }
      console.log(this.props.match.eliminations.tieSources);
      if (this.props.match.eliminations.tieSources && this.props.match.scores) {
        
        this.props.match.eliminations.tieSources.forEach(tieSource => {
          calculateWinner(tieSource);
        });
      }
    }

    return (
      <div className="projector-screen" style={{ opacity: this.props.opacity }}>
        <div className="header">
          <span>{header}</span>
          <span>Match Results</span>
        </div>
        <div className="scores-container">
          <div className="scores red">
            <div className="scores-teams">
              <div className="left">
                <div>{red1}</div>
                <div>{red2}</div>
              </div>
              <div>
                {!this.props.match.eliminations && <div>{red1Ranking}</div>}
                {!this.props.match.eliminations && <div>{red2Ranking}</div>}
              </div>
            </div>
            <div
              className="points-row"
              style={{ gridTemplateColumns: this.props.enableRankingPoints ? "1fr 2fr" : undefined }}
            >
              {this.props.enableRankingPoints && (
                <div className="ranking-point-container">
                  {this.props.match.eliminations && <div className="new-high-score wins">Wins</div>}
                  {!this.props.match.eliminations ? (
                    <div>
                      <span>{this.props.match.scores.redRankingPoints}</span>RP
                    </div>
                  ) : (
                    <div>
                      <span>{redWins}</span>
                    </div>
                  )}
                </div>
              )}
              <div className="score-container">
                <div
                  className="new-high-score"
                  style={{
                    display:
                      this.props.match.scores.red === this.props.highScore && (this.props.match.eliminations
                        ? this.props.match.eliminations.shortTitle === this.props.highScoreMatch
                        : this.props.match.num === this.props.highScoreMatch)
                        ? "block"
                        : "none"
                  }}
                >
                  <span>NEW HIGH SCORE</span>
                </div>
                <span>{this.props.match.scores.red}</span>
              </div>
            </div>
            <div className="scores-breakdown red dull">
              {this.props.match.scores.liveScoreBreakdown ? (
                <table style={{ width: "100%" }}>
                  <tbody>
                    {this.props.match.scores.liveScoreBreakdown.red.map(score => (
                      <tr key={score.name}>
                        <td>{score.name}:</td>
                        <td className="bold">{score.value}</td>
                      </tr>
                    ))}
                    <tr>
                      <td>Blue's Penalties:</td>
                      <td className="bold">{this.props.match.scores.bluePenalty}</td>
                    </tr>
                  </tbody>
                </table>
              ) : (
                <div>
                  <div>Red Score: {this.props.match.scores.red - this.props.match.scores.bluePenalty}</div>
                  <div>Blue's Penalties: {this.props.match.scores.bluePenalty}</div>
                </div>
              )}
            </div>
          </div>
          <div className="scores blue">
            <div className="scores-teams">
              <div className="left">
                <div>{blue1}</div>
                <div>{blue2}</div>
              </div>
              <div>
                {!this.props.match.eliminations && <div>{blue1Ranking}</div>}
                {!this.props.match.eliminations && <div>{blue2Ranking}</div>}
              </div>
            </div>
            <div
              className="points-row blue"
              style={{ gridTemplateColumns: this.props.enableRankingPoints ? "2fr 1fr" : undefined }}
            >
              <div className="score-container">
                <div
                  className="new-high-score"
                  style={{
                    display:
                      this.props.match.scores.blue === this.props.highScore && (this.props.match.eliminations
                        ? this.props.match.eliminations.shortTitle === this.props.highScoreMatch
                        : this.props.match.num === this.props.highScoreMatch)
                        ? "block"
                        : "none"
                  }}
                >
                  <span>NEW HIGH SCORE</span>
                </div>
                <span>{this.props.match.scores.blue}</span>
              </div>
              {this.props.enableRankingPoints && (
                <div className="ranking-point-container">
                  {this.props.match.eliminations && <div className="new-high-score wins">Wins</div>}
                  {!this.props.match.eliminations ? (
                    <div>
                      <span>{this.props.match.scores.blueRankingPoints}</span>RP
                    </div>
                  ) : (
                    <div>
                      <span>{blueWins}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
            <div className="scores-breakdown blue dull">
              {this.props.match.scores.liveScoreBreakdown ? (
                <table style={{ width: "100%" }}>
                  <tbody>
                    {this.props.match.scores.liveScoreBreakdown.blue.map(score => (
                      <tr key={score.name}>
                        <td>{score.name}:</td>
                        <td className="bold">{score.value}</td>
                      </tr>
                    ))}
                    <tr>
                      <td>Red's Penalties:</td>
                      <td className="bold">{this.props.match.scores.redPenalty}</td>
                    </tr>
                  </tbody>
                </table>
              ) : (
                <div>
                  <div>Blue Score: {this.props.match.scores.blue - this.props.match.scores.redPenalty}</div>
                  <div>Red's Penalties: {this.props.match.scores.redPenalty}</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default MatchScores;
