import React from "react";
import { animateScroll as scroll } from "react-scroll";

class PreMatchScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      position: "top"
    };
  }

  componentDidMount() {
    this.scroll();
    setInterval(() => {
      this.scroll();
    }, 20000);
  }

  scroll() {
    if (this.state.position === "top") {
      scroll.scrollToBottom({
        containerId: "rankings-prematch",
        smooth: "linear",
        duration: 10000
      });
      this.setState({
        position: "bottom"
      });
    } else {
      scroll.scrollToTop({
        containerId: "rankings-prematch",
        smooth: "linear",
        duration: 10000
      });
      this.setState({
        position: "top"
      });
    }
  }

  render() {
    let overrideEnabled = this.props.overrideInfo && this.props.overrideInfo.enabled;

    let header = overrideEnabled 
      ? this.props.overrideInfo.header
      : this.props.match.eliminations
      ? this.props.match.eliminations.title
      : "Qualification Match " + this.props.match.num;
    let red1 = overrideEnabled ? this.props.overrideInfo.red1 : this.props.match.red1;
    let red2 = overrideEnabled ? this.props.overrideInfo.red2 : this.props.match.red2;
    let blue1 = overrideEnabled ? this.props.overrideInfo.blue1 : this.props.match.blue1;
    let blue2 = overrideEnabled ? this.props.overrideInfo.blue2 : this.props.match.blue2;

    if (!overrideEnabled && this.props.match.surrogates && this.props.match.surrogates.red1) red1 += " (Surrogate)";
    if (!overrideEnabled && this.props.match.surrogates && this.props.match.surrogates.red2) red2 += " (Surrogate)";
    if (!overrideEnabled && this.props.match.surrogates && this.props.match.surrogates.blue1) blue1 += " (Surrogate)";
    if (!overrideEnabled && this.props.match.surrogates && this.props.match.surrogates.blue2) blue2 += " (Surrogate)";

    return (
      <div className="projector-screen" style={{ opacity: this.props.opacity }}>
        <div className="header">
          <span>{header}</span>
          <span>Match Preview</span>
        </div>
        <div className="versus-container">
          <div className="versus-teams-container left">
            <div className="versus-team red">{red1}</div>
            <div className="versus-team red">{red2}</div>
          </div>
          <div className="versus">vs</div>
          <div className="versus-teams-container right">
            <div className="versus-team blue">{blue1}</div>
            <div className="versus-team blue">{blue2}</div>
          </div>
        </div>
        <div className="prematch-rankings">
          <div
            id="rankings-prematch"
            className="no-scroll-bar"
            style={{
              fontSize: "1.5em",
              textAlign: "left",
              fontWeight: "normal",
              width: "100%",
              height: "100%",
              overflow: "auto"
            }}
          >
            <table className="rankings-table" cellSpacing="0">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Team</th>
                  {this.props.enableRankingPoints && <th>Avg. RP</th>}
                  <th>Record</th>
                  <th>Total Penalty (Committed)</th>
                </tr>
              </thead>
              <tbody>
                {this.props.rankings &&
                  this.props.rankings.map(team => (
                    <tr key={team.name}>
                      <td>{String(team.rank).padStart(2, "0")}</td>
                      <td>{team.name}</td>
                      {this.props.enableRankingPoints && (
                        <td>{(team.totalRankingPoints / Object.values(team.scoreHistory).length || 0).toFixed(2)}</td>
                      )}
                      <td>
                        ({team.totalWins || 0}-{team.totalLosses || 0}-{team.totalTies || 0})
                      </td>
                      <td>{team.totalPenaltyPoints || 0}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}

export default PreMatchScreen;
