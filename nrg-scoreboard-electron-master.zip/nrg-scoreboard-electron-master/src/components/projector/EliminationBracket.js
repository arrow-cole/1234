import React from "react";
import { Icon } from "semantic-ui-react";

class EliminationBracket extends React.Component {
  render() {
    if (!this.props.matches) return <div />;

    let qualifications = this.props.matches.filter(match => {
      return (
        match.eliminations &&
        match.eliminations.shortTitle.startsWith(this.props.matches[0].eliminations.shortTitle[0]) &&
        !match.eliminations.shortTitle.includes("TB")
      );
    });
    if (this.props.doubleEliminations) {
      qualifications = qualifications.slice(0, qualifications.length / 2);
    }

    let semifinals = this.props.matches.filter(match => {
      return (
        match.eliminations &&
        !this.props.matches[0].eliminations.shortTitle.startsWith("F") &&
        match.eliminations.shortTitle.startsWith(
          this.props.matches[0].eliminations.shortTitle[0] === "Q" ? "S" : "F"
        ) &&
        !match.eliminations.shortTitle.includes("TB")
      );
    });
    if (this.props.doubleEliminations) {
      semifinals = semifinals.slice(0, semifinals.length / 2);
    }

    let finals = this.props.matches.filter(match => {
      return (
        match.eliminations &&
        this.props.matches[0].eliminations.shortTitle.startsWith("Q") &&
        match.eliminations.shortTitle.startsWith("F") &&
        !match.eliminations.shortTitle.includes("TB")
      );
    });
    if (this.props.doubleEliminations) {
      finals = finals.slice(0, finals.length / 2);
    }

    return (
      <div className="projector-screen elimination-bracket" style={{ opacity: this.props.opacity }}>
        <h1>PLAYOFF BRACKET</h1>
        <div
          style={{
            marginLeft: "2.5vw",
            top: "50%",
            position: "absolute",
            transform: "translateY(-50%)"
          }}
        >
          {qualifications.map(match => (
            <div
              className="elimination-bracket-match"
              style={{ marginBottom: match.num !== qualifications.length ? "0.6em" : "0" }}
              key={match.num}
            >
              <div className="elimination-bracket-match-title">
                <MatchLabel text={match.eliminations.shortTitle} next={this.props.nextMatch === match.num} />
                {this.props.doubleEliminations && (
                  <span>
                    {" / "}
                    <MatchLabel
                      text={this.props.matches[match.num - 1 + qualifications.length].eliminations.shortTitle}
                      next={this.props.nextMatch === this.props.matches[match.num - 1 + qualifications.length].num}
                    />
                    {!this.props.matches[match.num - 1 + 2 * qualifications.length].eliminations.hide && (
                      <span>
                        {" / "}
                        <MatchLabel
                          text={this.props.matches[match.num - 1 + 2 * qualifications.length].eliminations.shortTitle}
                          next={
                            this.props.nextMatch === this.props.matches[match.num - 1 + 2 * qualifications.length].num
                          }
                        />
                      </span>
                    )}
                  </span>
                )}
              </div>
              <div style={{ position: "relative" }}>
                <div className="elimination-bracket-row">
                  <div className="elimination-bracket-team-container red">
                    <div className="elimination-bracket-team">{match.red1}</div>
                    <div className="elimination-bracket-team">{match.red2}</div>
                  </div>
                  <WinIndicators
                    team="red"
                    match1={match}
                    match2={this.props.matches[match.num - 1 + qualifications.length]}
                    tiebreaker={this.props.matches[match.num - 1 + qualifications.length * 2]}
                  />
                </div>
                <div className="elimination-bracket-row">
                  <div className="elimination-bracket-team-container blue">
                    <div className="elimination-bracket-team">{match.blue1}</div>
                    <div className="elimination-bracket-team">{match.blue2}</div>
                  </div>
                  <WinIndicators
                    team="blue"
                    match1={match}
                    match2={this.props.matches[match.num - 1 + qualifications.length]}
                    tiebreaker={this.props.matches[match.num - 1 + qualifications.length * 2]}
                  />
                </div>
                {match.eliminations.shortTitle.match(/[QS]/) && (
                  <Arrow direction={match.num % 2 === 0 ? "up" : "down"} long={false} />
                )}
              </div>
            </div>
          ))}
        </div>
        <div
          style={{
            marginLeft: "35vw",
            top: "50%",
            position: "absolute",
            transform: "translateY(-50%)"
          }}
        >
          {semifinals.map(match => (
            <div
              className="elimination-bracket-match"
              style={{ marginBottom: match.eliminations.shortTitle.match(/S.1/) ? "7em" : "0" }}
              key={match.num}
            >
              <div className="elimination-bracket-match-title">
                <MatchLabel text={match.eliminations.shortTitle} next={this.props.nextMatch === match.num} />
                {this.props.doubleEliminations && (
                  <span>
                    {" / "}
                    <MatchLabel
                      text={this.props.matches[match.num - 1 + qualifications.length / 2].eliminations.shortTitle}
                      next={this.props.nextMatch === this.props.matches[match.num - 1 + qualifications.length / 2].num}
                    />
                    {!this.props.matches[match.num - 1 + (2 * qualifications.length) / 2].eliminations.hide && (
                      <span>
                        {" / "}
                        <MatchLabel
                          text={
                            this.props.matches[match.num - 1 + (2 * qualifications.length) / 2].eliminations.shortTitle
                          }
                          next={
                            this.props.nextMatch ===
                            this.props.matches[match.num - 1 + (2 * qualifications.length) / 2].num
                          }
                        />
                      </span>
                    )}
                  </span>
                )}
              </div>
              <div style={{ position: "relative" }}>
                <div className="elimination-bracket-row">
                  <div className="elimination-bracket-team-container red">
                    <div className="elimination-bracket-team">{match.red1 || "???"}</div>
                    <div className="elimination-bracket-team">{match.red2 || "???"}</div>
                  </div>
                  <WinIndicators
                    team="red"
                    match1={match}
                    match2={this.props.matches[match.num - 1 + qualifications.length / 2]}
                    tiebreaker={this.props.matches[match.num - 1 + qualifications.length]}
                  />
                </div>
                <div className="elimination-bracket-row">
                  <div className="elimination-bracket-team-container blue">
                    <div className="elimination-bracket-team">{match.blue1 || "???"}</div>
                    <div className="elimination-bracket-team">{match.blue2 || "???"}</div>
                  </div>
                  <WinIndicators
                    team="blue"
                    match1={match}
                    match2={this.props.matches[match.num - 1 + qualifications.length / 2]}
                    tiebreaker={this.props.matches[match.num - 1 + qualifications.length]}
                  />
                </div>
                {match.eliminations.shortTitle.startsWith("S") && (
                  <Arrow direction={match.num % 2 === 0 ? "up" : "down"} long={true} />
                )}
              </div>
            </div>
          ))}
        </div>
        <div
          style={{
            marginLeft: "67.5vw",
            top: "50%",
            position: "absolute",
            transform: "translateY(-50%)"
          }}
        >
          {finals.map(match => (
            <div className="elimination-bracket-match" key={match.num}>
              <div className="elimination-bracket-match-title">
                <MatchLabel text={match.eliminations.shortTitle} next={this.props.nextMatch === match.num} />
                {this.props.doubleEliminations && (
                  <span>
                    {" / "}
                    <MatchLabel
                      text={this.props.matches[match.num - 1 + qualifications.length / 2 / 2].eliminations.shortTitle}
                      next={
                        this.props.nextMatch === this.props.matches[match.num - 1 + qualifications.length / 2 / 2].num
                      }
                    />
                    {!this.props.matches[match.num - 1 + (2 * qualifications.length) / 2 / 2].eliminations.hide && (
                      <span>
                        {" / "}
                        <MatchLabel
                          text={
                            this.props.matches[match.num - 1 + (2 * qualifications.length) / 2 / 2].eliminations
                              .shortTitle
                          }
                          next={
                            this.props.nextMatch ===
                            this.props.matches[match.num - 1 + (2 * qualifications.length) / 2 / 2].num
                          }
                        />
                      </span>
                    )}
                  </span>
                )}
              </div>
              <div style={{ position: "relative" }}>
                <div className="elimination-bracket-row">
                  <div className="elimination-bracket-team-container red">
                    <div className="elimination-bracket-team">{match.red1 || "???"}</div>
                    <div className="elimination-bracket-team">{match.red2 || "???"}</div>
                  </div>
                  <WinIndicators
                    team="red"
                    match1={match}
                    match2={this.props.matches[match.num - 1 + qualifications.length / 2 / 2]}
                    tiebreaker={this.props.matches[match.num - 1 + qualifications.length / 2]}
                  />
                </div>
                <div className="elimination-bracket-row">
                  <div className="elimination-bracket-team-container blue">
                    <div className="elimination-bracket-team">{match.blue1 || "???"}</div>
                    <div className="elimination-bracket-team">{match.blue2 || "???"}</div>
                  </div>
                  <WinIndicators
                    team="blue"
                    match1={match}
                    match2={this.props.matches[match.num - 1 + qualifications.length / 2 / 2]}
                    tiebreaker={this.props.matches[match.num - 1 + qualifications.length / 2]}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
        {this.props.doubleEliminations && (
          <div
            style={{
              margin: 0,
              position: "absolute",
              right: ".25em",
              bottom: ".25em",
              fontSize: "3.5em"
            }}
          >
            each round is best of 3
          </div>
        )}
      </div>
    );
  }
}

function Arrow(props) {
  return (
    <div className="elimination-arrow-container">
      <div className="elimination-arrow-seg-1" />
      <div
        className="elimination-arrow-seg-2"
        style={{
          top: props.long ? "50%" : props.direction === "down" ? "37%" : "63%",
          borderTop: props.direction === "down" ? ".25em solid white" : "",
          borderBottom: props.direction === "up" ? ".25em solid white" : "",
          transform: props.direction === "down" ? "translateX(100%)" : "translate(100%, -95%)",
          height: props.long ? "3.75em" : "1.25em"
        }}
      />
      <div
        className="elimination-arrow-seg-3"
        style={{
          borderTop: props.direction === "down" ? ".5em solid white" : "",
          borderBottom: props.direction === "up" ? ".5em solid white" : "",
          top: props.long ? (props.direction === "down" ? "116%" : "-16%") : "50%",
          transform: props.direction === "down" ? "translate(37%, 57%)" : "translate(37%, -147%)"
        }}
      />
    </div>
  );
}

function MatchLabel(props) {
  return (
    <span className={props.next ? "elimination-bracket-next-match" : ""}>
      {props.next && "Next: "}
      {props.text}
    </span>
  );
}

function WinIndicators(props) {
  let opponent = team => {
    return team === "red" ? "blue" : "red";
  };
  let shouldHaveIndicator = match => {
    return match && match.scores && match.scores[props.team] > match.scores[opponent(props.team)];
  };
  return (
    <div
      style={{
        position: "absolute",
        right: ".25em",
        top: props.team === "red" ? "25%" : "75%",
        transform: "translateY(-50%)",
        fontSize: "0.5em",
        display: "flex",
        flexDirection: "column"
      }}
    >
      {shouldHaveIndicator(props.match1) && <Icon name="circle check" size="small" style={{ margin: ".25em 0" }} />}
      {shouldHaveIndicator(props.match2) && <Icon name="circle check" size="small" style={{ margin: ".25em 0" }} />}
      {shouldHaveIndicator(props.tiebreaker) && <Icon name="circle check" size="small" style={{ margin: ".25em 0" }} />}
    </div>
  );
}

export default EliminationBracket;
