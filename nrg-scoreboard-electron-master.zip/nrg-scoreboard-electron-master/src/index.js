import React from "react";
import ReactDOM from "react-dom";
import "semantic-ui-css/semantic.min.css";
import "./css/stylesheet.css";
import "./css/field-controls.css";
import App from "./App";
import { getBackupFilePath } from "./util/util.js";

require("typeface-lato");

const fs = window.require("@electron/remote").require("fs");

var backup = null;

fs.readFile(getBackupFilePath(), "utf8", function readFileCallback(err, data) {
  if (err) {
    console.log("error occurred when attempting to read backup:");
    console.log(err);
  } else {
    try {
      backup = JSON.parse(data);
      console.log("successfully read and parsed backup file");
    } catch (e) {
      console.log("Backup file JSON was invalid... ignoring.");
    }
  }

  ReactDOM.render(<App backup={backup} />, document.getElementById("root"));
});
