import React from "react";
import { MemoryRouter as Router, Route, Redirect } from "react-router-dom";
import "semantic-ui-css/semantic.min.css";
import "./css/stylesheet.css";
import "./css/field-controls.css";

import MainPage from "./components/main/MainPage";
import SetupMatchSchedule from "./components/main/SetupMatchSchedule";
import SetupLoadBackup from "./components/main/SetupLoadBackup";
import Projector from "./components/projector/Projector";

import start_auto from "./audio/start_auto.wav";
import start_teleop from "./audio/start_teleop.wav";
import begin_end_game from "./audio/begin_end_game.wav";
import end_match from "./audio/end_match.wav";
import abort_match from "./audio/abort_match.wav";

import { getBackupFilePath, getScheduleCSVFilePath } from "./util/util.js";
import Rankings from "./util/rankings.js";
import Eliminations from "./util/eliminations.js";
import SettingsPage from "./components/main/SettingsPage";

const electron = window.require("electron");
const remote = window.require("@electron/remote");
const fs = window.require("@electron/remote").require("fs");

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      id: "code-red-2771-nrg-scoreboard-backup",
      currentMatch: 1,
      currentField: 1,
      matchRunning: false,
      timeRemaining: 135,
      teleopStart: 120,
      endGameStart: 30,
      matchDuration: 135,
      enableAutonomous: true,
      enableEndGame: true,
      mqttBrokerLocation: "localhost",
      enableRankingPoints: true,
      rankingOrderSelections: Rankings.defaultRankingOrders(),
      enablePyramidPuzzleHotColor: false,
      currentHotColor: "none",
      projectorMode: "nrg-logo-only",
      opModes: {
        field1: "automatic",
        field1Effective: "disabled",
        field2: "automatic",
        field2Effective: "disabled",
      },
      audio: {
        enable: true,
        startAuto: new Audio(start_auto),
        startTeleop: new Audio(start_teleop),
        beginEndGame: new Audio(begin_end_game),
        endMatch: new Audio(end_match),
        abortMatch: new Audio(abort_match),
      },
      status: {
        field1: {
          fcs: "disconnected",
          red1: "norobot",
          red2: "norobot",
          blue1: "norobot",
          blue2: "norobot",
        },
        field2: {
          fcs: "disconnected",
          red1: "norobot",
          red2: "norobot",
          blue1: "norobot",
          blue2: "norobot",
        },
        other: {
          mqtt: "disconnected",
          liveScore: "disconnected",
          liveScorePhones: 0,
          queueing: "disconnected",
        },
      },
      liveScore: {
        enabled: true,
        appLocation: "./",
        liveScores: {
          redPoints: 0,
          bluePoints: 0,
          redPenalty: 0,
          bluePenalty: 0,
        },
        finalScores: {
          red: null,
          blue: null,
        },
      },
      eliminations: false,
      projectorOverride: {
        modalOpen: false,
        enabled: false,
      },
      editTeamNameModalOpen: false,
      addLateCompetitorModalOpen: false,
      removeCompetitorModalOpen: false,
      awardsModalOpen: false,
      highScore: -1,
      highScoreMatch: -1,
      finishedQualificationMatches: [],
      matches: [],
      teams: [],
      teamMenuOptions: [],
      numTeams: 0,
      numMatchesPerTeam: 0,
      sortedRankings: [],
      redirectEnabled: false,
      isProjector: false,
      rankingsScroll: true,
      awards: [
        { name: "", team: "" },
        { name: "", team: "" },
        { name: "", team: "" },
        { name: "", team: "" },
      ],
      activeAward: "nrg-logo-only",
      showAwardWinner: false,
    };

    electron.ipcRenderer.on("set-is-projector", (e, isProjector) => {
      this.setState({
        redirectEnabled: isProjector,
        redirectLocation: "/projector",
        isProjector: isProjector,
      });
      if (!isProjector) {
        this.registerMenuHandlers();
        this.registerStatusHandlers();
        electron.ipcRenderer.send("set-livescore-app-location", this.state.liveScore.appLocation);
      }
    });
    electron.ipcRenderer.send("request-is-projector", true);
  }

  componentDidUpdate() {
    if (this.state.redirectEnabled) {
      this.setState({
        redirectEnabled: false,
      });
    }

    if (!this.state.isProjector) {
      electron.ipcRenderer.send("update-projector", {
        ...this.state,
        audio: undefined, // Audio objects cannot be serialized, and Electron 9+ will throw an error if you try
      });
    }
  }

  registerMenuHandlers() {
    electron.ipcRenderer.on("menu-action", async (e, action) => {
      switch (action) {
        case "reload-from-backup":
          await remote.dialog
            .showOpenDialog({
              title: "Select backup.json to reload from",
              defaultPath: getBackupFilePath(),
              filters: [{ name: "Backup Files (.json)", extensions: ["json"] }],
              properties: ["openFile"],
            })
            .then((data) => {
              if (!data || !data.filePaths) return;

              fs.readFile(
                data.filePaths[0],
                "utf8",
                function readFileCallback(err, data) {
                  if (err) {
                    remote.dialog.showMessageBox({
                      message: "An error occurred while reading the backup file.",
                    });
                  } else {
                    try {
                      let backup = JSON.parse(data);
                      if (!backup.id || backup.id !== "code-red-2771-nrg-scoreboard-backup") {
                        remote.dialog.showMessageBox({
                          message: "The selected file is not an NRG Scoreboard backup file.",
                        });
                      } else {
                        this.loadBackup(backup);
                      }
                    } catch (e) {
                      console.log(e);
                      remote.dialog.showMessageBox({
                        message: "The backup file did not have a valid JSON format.",
                      });
                    }
                  }
                }.bind(this)
              );
            });
          break;
        case "generate-schedule":
          var confirmation = window.confirm(
            "Are you sure you want to generate a new schedule? Existing data will be lost."
          );
          if (confirmation) {
            electron.ipcRenderer.send("app-loaded-schedule", false);
            this.setState({
              redirectEnabled: true,
              redirectLocation: "/setupTeams",
              projectorMode: "nrg-logo-only",
              currentMatch: 1,
              eliminations: false,
              currentField: 1,
              editTeamNameModalOpen: false,
              addLateCompetitorModalOpen: false,
              removeCompetitorModalOpen: false,
              highScore: -1,
              highScoreMatch: -1,
            });
          }
          break;
        case "manual-override":
          this.setState({
            projectorOverride: {
              ...this.state.projectorOverride,
              ...{ modalOpen: true },
            },
          });
          break;
        case "disable-override":
          this.setState({
            projectorOverride: {
              modalOpen: false,
              enabled: false,
            },
          });
          break;
        case "add-more-matches":
          if (this.state.eliminations) {
            remote.dialog.showMessageBox({ message: "You can only add more matches to qualifications." });
            return;
          }
          this.setState({
            addMoreMatchesModalOpen: true,
          });
          break;
        case "edit-schedule":
          if (this.state.eliminations) {
            remote.dialog.showMessageBox({
              message: "Can't edit schedule during eliminations. Use Override Eliminations Advancement instead. ",
            });
          } else {
            this.setState({
              editScheduleModalOpen: true,
            });
          }
          break;
        case "edit-team-names":
          this.setState({
            editTeamNameModalOpen: true,
          });
          break;
        case "add-late-competitor":
          if (this.state.eliminations) {
            remote.dialog.showMessageBox({
              message: "You can't add competitors while eliminations is active.",
            });
            return;
          }
          this.setState({
            addLateCompetitorModalOpen: true,
          });
          break;
        case "remove-competitor":
          if (this.state.eliminations) {
            remote.dialog.showMessageBox({
              message:
                "You can't remove a competitor while eliminations is active. As a workaround, replace that team using the Override Automatic Advancements feature.",
            });
            return;
          }
          if (this.state.numTeams <= 4) {
            remote.dialog.showMessageBox({
              title: "Cannot Remove Team",
              message: "There are only 4 competing teams, cannot remove any of them.",
            });
            break;
          }
          this.setState({
            removeCompetitorModalOpen: true,
          });
          break;
        case "open-settings":
          this.setState({
            redirectEnabled: true,
            redirectLocation: "/settings",
          });
          break;
        case "export-schedule-to-csv":
          let filePath = remote.dialog.showSaveDialogSync({
            title: "Export Match Schedule to CSV",
            defaultPath: getScheduleCSVFilePath(),
          });
          if (!filePath) return;

          var data = "Match #, Red 1, Red 2, Blue 1, Blue 2 \n";
          for (var i = 0; i < this.state.matches.length; i++) {
            data +=
              this.state.matches[i].num +
              "," +
              this.state.matches[i].red1 +
              "," +
              this.state.matches[i].red2 +
              "," +
              this.state.matches[i].blue1 +
              "," +
              this.state.matches[i].blue2 +
              "\n";
          }
          fs.writeFile(filePath, data, () => {});
          break;
        default:
          remote.dialog.showMessageBox({ message: "Not implemented" });
          break;
      }
    });
  }

  registerStatusHandlers() {
    electron.ipcRenderer.on("robot-status-update", (e, data) => {
      let status = this.state.status;
      let robot = data.robot.replace("R", "red").replace("B", "blue");
      status["field" + data.field][robot] = data.opMode;
      console.log("new status: " + status);
      this.setState({
        status: status,
      });
    });
    electron.ipcRenderer.on("fcs-status-update", (e, data) => {
      let status = this.state.status;
      status["field" + data.field].fcs = data.status;
      this.setState({
        status: status,
      });
    });
    electron.ipcRenderer.on("mqtt-connection-change", (e, state) => {
      let status = this.state.status;
      status.other.mqtt = state;
      this.setState({
        status: status,
      });
    });
    // mqtt.js sends the initial status message before react has started,
    // so request the initial state
    electron.ipcRenderer.send("request-mqtt-connection-state", null);
    electron.ipcRenderer.on("livescore-phone-count-update", (e, num) => {
      let status = this.state.status;
      status.other.liveScorePhones = num;
      this.setState({
        status: status,
      });
    });
    electron.ipcRenderer.on("livescore-score-update", (e, data) => {
      let liveScore = this.state.liveScore;
      let points = 0;
      let penalty = 0;
      data.score.forEach((score) => {
        if (score.name === "Penalties") {
          penalty = score.value;
        } else {
          points += Number(score.value);
        }
      });

      if (data.alliance.toLowerCase() === "red") {
        liveScore.liveScores.redPoints = points;
        liveScore.liveScores.redPenalty = penalty;
      } else {
        liveScore.liveScores.bluePoints = points;
        liveScore.liveScores.bluePenalty = penalty;
      }

      this.setState({
        liveScore: liveScore,
      });
    });
    electron.ipcRenderer.on("livescore-submit-final-scores", (e, data) => {
      let liveScore = this.state.liveScore;
      if (data.alliance.toLowerCase() === "red") {
        liveScore.finalScores.red = data.score;
      } else {
        liveScore.finalScores.blue = data.score;
      }

      this.setState({
        liveScore: liveScore,
      });
    });
  }

  handleIncDecMatch(currentMatch, shift) {
    currentMatch = currentMatch ? currentMatch : this.state.currentMatch + shift;
    while (
      this.state.matches[currentMatch - 1] &&
      this.state.matches[currentMatch - 1].eliminations &&
      (this.state.matches[currentMatch - 1].eliminations.hide ||
        !this.state.matches[currentMatch - 1].red1 ||
        !this.state.matches[currentMatch - 1].blue1)
    ) {
      currentMatch += shift;
    }

    if (!this.state.matches[currentMatch - 1]) {
      return; // can't increment, do nothing
    }

    let projectorMode = this.state.projectorMode;
    if (!this.state.eliminations) {
      if (currentMatch > this.state.currentMatch && this.state.projectorMode === "prematch-next") {
        projectorMode = "prematch-current";
      } else if (currentMatch < this.state.currentMatch && this.state.projectorMode === "prematch-current") {
        projectorMode = "prematch-next";
      } else if (projectorMode === "match-scores" && !this.state.matches[currentMatch - 1].scores) {
        projectorMode = "nrg-logo-only";
      }
    } else {
      if (currentMatch > this.state.currentMatch && this.state.projectorMode === "elimination-bracket-next") {
        projectorMode = "elimination-bracket-current";
      } else if (currentMatch < this.state.currentMatch && this.state.projectorMode === "elimination-bracket-current") {
        projectorMode = "elimination-bracket-next";
      } else if (projectorMode === "match-scores" && !this.state.matches[currentMatch - 1].scores) {
        projectorMode = "nrg-logo-only";
      }
    }
    let liveScore = this.state.liveScore;
    liveScore.liveScores = {
      redPoints: 0,
      bluePoints: 0,
      redPenalty: 0,
      bluePenalty: 0,
    };
    this.setState({
      currentMatch: currentMatch,
      timeRemaining: this.state.matchDuration,
      currentHotColor: "none",
      currentField: this.state.currentField === 1 ? 2 : 1,
      projectorMode: projectorMode,
      liveScore: liveScore,
    });
  }

  handleSetField(field) {
    this.setState({
      currentField: field,
    });
  }

  handleStartStopMatch(isStart) {
    if (isStart) {
      if (this.state.audio.enable) {
        this.state.audio.startAuto.play();
      }
      if (this.state.opModes["field" + this.state.currentField] === "automatic") {
        electron.ipcRenderer.send("opMode-update", {
          field: this.state.currentField,
          opMode: this.state.enableAutonomous ? "autonomous" : "teleop",
        });
      }
      clearInterval(this.state.timerId); // extra cautious
      let opModes = this.state.opModes;
      if (this.state.currentField === 1) {
        opModes.field1Effective = "teleop";
      } else if (this.state.currentField === 2) {
        opModes.field2Effective = "teleop";
      }
      this.setState({
        matchRunning: true,
        timeRemaining: this.state.matchDuration,
        opModes: opModes,
        currentHotColor: "none",
        timerId: setInterval(() => {
          let effectiveOpMode = this.state.timeRemaining > this.state.endGameStart ? "teleop" : "endgame";
          let currentHotColor = this.state.currentHotColor;
          if (this.state.timeRemaining === 1) {
            clearInterval(this.state.timerId); // match is done, stop updating
            if (this.state.audio.enable) {
              this.state.audio.endMatch.play();
            }
            if (this.state.opModes["field" + this.state.currentField] === "automatic") {
              electron.ipcRenderer.send("opMode-update", {
                field: this.state.currentField,
                opMode: "disabled",
              });
            }
            effectiveOpMode = "disabled";
          } else if (
            this.state.enableEndGame &&
            Number(this.state.timeRemaining) === Number(this.state.endGameStart) + 1
          ) {
            console.log("TIME TO START ENDGAME");
            if (this.state.audio.enable) {
              console.log("playing end game start noise");
              this.state.audio.beginEndGame.play();
            }
            if (this.state.enablePyramidPuzzleHotColor) {
              const colors = ["green", "yellow", "hotpink", "orange"];
              currentHotColor = colors[Math.floor(Math.random() * colors.length)];
            }
            if (this.state.opModes["field" + this.state.currentField] === "automatic") {
              electron.ipcRenderer.send("opMode-update", {
                field: this.state.currentField,
                opMode: "endgame",
              });
            }
            effectiveOpMode = "endgame";
          } else if (this.state.enableAutonomous && this.state.timeRemaining === this.state.teleopStart + 1) {
            if (this.state.audio.enable) {
              this.state.audio.startTeleop.play();
            }
            if (this.state.opModes["field" + this.state.currentField] === "automatic") {
              electron.ipcRenderer.send("opMode-update", {
                field: this.state.currentField,
                opMode: "teleop",
              });
            }
          }
          opModes = this.state.opModes;
          if (this.state.currentField === 1) {
            opModes.field1Effective = effectiveOpMode;
          } else if (this.state.currentField === 2) {
            opModes.field2Effective = effectiveOpMode;
          }
          this.setState(
            {
              timeRemaining: this.state.timeRemaining - 1,
              matchRunning: this.state.timeRemaining - 1 > 0,
              opModes: opModes,
              currentHotColor,
            },
            () => {
              electron.ipcRenderer.send("time-update", {
                field: this.state.currentField,
                time: this.state.timeRemaining,
              });
            }
          );
        }, 1000),
      });
      electron.ipcRenderer.send("time-update", { field: this.state.currentField, time: this.state.matchDuration });
    } else {
      if (this.state.audio.enable) {
        this.state.audio.abortMatch.play();
      }
      let opModes = this.state.opModes;
      opModes.field1Effective = "disabled";
      opModes.field2Effective = "disabled";
      this.setState({
        matchRunning: false,
        timeRemaining: 0,
        opModes: opModes,
      });
      electron.ipcRenderer.send("time-update", { field: this.state.currentField, time: 0 });
      clearInterval(this.state.timerId);
    }
  }

  handleChangeProjectorMode(mode) {
    this.setState({
      projectorMode: mode,
    });
  }

  handleChangeOpModes(field, opMode) {
    let opModes = this.state.opModes;
    if (field === 1) {
      opModes.field1 = opMode;
    } else if (field === 2) {
      opModes.field2 = opMode;
    }
    this.setState({
      opModes: opModes,
    });
    electron.ipcRenderer.send("opMode-update", {
      field: field,
      opMode: opMode,
    });
  }

  handleStartEliminations(size, doubleEliminations, teamSelections) {
    if (!this.state.eliminations) {
      let matches = Eliminations.generateSchedule(size, doubleEliminations, teamSelections);
      this.setState(
        {
          currentMatch: 1,
          eliminations: true,
          projectorMode: this.state.projectorMode.startsWith("prematch") ? "nrg-logo-only" : this.state.projectorMode,
          doubleEliminations: doubleEliminations,
          finishedQualificationMatches: this.state.matches,
          matches: matches,
        },
        () => {
          this.writeBackup();
        }
      );
    } else {
      var confirmation = window.confirm(
        "Are you sure you want to stop eliminations? Any scores in elimination matches will be lost."
      );
      if (confirmation) {
        this.setState(
          {
            currentMatch: 1,
            eliminations: false,
            projectorMode: this.state.projectorMode.startsWith("elimination-bracket")
              ? "nrg-logo-only"
              : this.state.projectorMode,
            matches: this.state.finishedQualificationMatches,
          },
          () => {
            this.writeBackup();
          }
        );
      }
    }
  }

  handleOverrideEliminationAdvancements(updateData) {
    let matches = this.state.matches;
    for (let i = 0; i < updateData.length; i++) {
      matches[i].red1 = updateData[i].red1;
      matches[i].red2 = updateData[i].red2;
      matches[i].blue1 = updateData[i].blue1;
      matches[i].blue2 = updateData[i].blue2;
      matches[i].eliminations.hide = updateData[i].hide;
    }
    this.setState(
      {
        matches: matches,
      },
      () => {
        this.writeBackup();
      }
    );
  }

  handleSubmitScores(matchIndex, scores) {
    // update match scores
    let matches = this.state.matches;
    let match = matches[matchIndex - 1];
    match.scores = {
      red: scores.redPoints + scores.bluePenalty,
      blue: scores.bluePoints + scores.redPenalty,
      redPenalty: scores.redPenalty,
      bluePenalty: scores.bluePenalty,
      redRankingPoints: scores.redRPs,
      blueRankingPoints: scores.blueRPs,
      liveScoreBreakdown: scores.liveScoreBreakdown,
    };

    // recalculate high scores
    var highScore = this.state.highScore;
    var highScoreMatch = this.state.highScoreMatch;
    let currentMatchIsHighScoreMatch =
      (!this.state.eliminations && match.num === this.state.highScoreMatch) ||
      (this.state.eliminations && match.eliminations.shortTitle === this.state.highScoreMatch);

    if (
      match.scores.red > this.state.highScore ||
      match.scores.blue > this.state.highScore ||
      currentMatchIsHighScoreMatch
    ) {
      highScore = Math.max(match.scores.red, match.scores.blue);
      highScoreMatch = match.eliminations ? match.eliminations.shortTitle : match.num;
    }

    // advance winning teams to the next round if this is an eliminations match
    if (match.eliminations) {
      Eliminations.advance(match);
      this.setState(
        {
          matches: matches,
          highScore: highScore,
          highScoreMatch: highScoreMatch,
        },
        () => {
          this.writeBackup();
        }
      );
      return;
    }

    let teams = this.state.teams;

    // update each team's total statistics
    if (!match.surrogates) match.surrogates = {};
    this.updateTeamStatistics(teams, match.red1, match, true, match.surrogates.red1);
    this.updateTeamStatistics(teams, match.red2, match, true, match.surrogates.red2);
    this.updateTeamStatistics(teams, match.blue1, match, false, match.surrogates.blue1);
    this.updateTeamStatistics(teams, match.blue2, match, false, match.surrogates.blue2);

    // recalculate rankings
    let sortedTeams = Rankings.rank(teams, this.state.rankingOrderSelections);

    // store the data
    let newTeamInfo = {};
    for (let t in sortedTeams) {
      sortedTeams[t].oldRank = sortedTeams[t].rank;
      sortedTeams[t].rank = Number(t) + 1;
      newTeamInfo[sortedTeams[t].name] = sortedTeams[t];
    }
    let liveScore = this.state.liveScore;
    liveScore.finalScores = {
      red: null,
      blue: null,
    };
    this.setState(
      {
        matches: matches,
        teams: newTeamInfo,
        sortedRankings: sortedTeams,
        highScore: highScore,
        highScoreMatch: highScoreMatch,
        liveScore: liveScore,
      },
      () => {
        this.writeBackup();
      }
    );
  }

  updateTeamStatistics(teams, team, match, isRed, isSurrogate) {
    if (isSurrogate) {
      return;
    }

    let win = isRed ? match.scores.red > match.scores.blue : match.scores.blue > match.scores.red;
    let loss = isRed ? match.scores.red < match.scores.blue : match.scores.blue < match.scores.red;
    teams[team].scoreHistory[match.num] = {
      rankingPoints: isRed ? match.scores.redRankingPoints : match.scores.blueRankingPoints,
      penaltyPoints: isRed ? match.scores.redPenalty : match.scores.bluePenalty,
      points: isRed ? match.scores.red - match.scores.bluePenalty : match.scores.blue - match.scores.redPenalty,
      matchScore: isRed ? match.scores.red : match.scores.blue,
      win: win,
      loss: loss,
      tie: !win && !loss,
    };
  }

  writeBackup() {
    let backup = {
      ...this.state,
    };
    backup.audio = undefined; // don't backup the audio objects
    if (this.state.eliminations) {
      backup.matches = Eliminations.unlinkMatches(backup.matches);
    }

    fs.writeFile(getBackupFilePath(), JSON.stringify(backup), "utf8", () => {});
  }

  handleSetProjectorFullscreen(e, data) {
    electron.ipcRenderer.send("set-projector-fullscreen", data.checked);
  }

  handleOverrideProjectorCancel() {
    this.setState({
      projectorOverride: {
        ...this.state.projectorOverride,
        ...{ modalOpen: false },
      },
    });
  }

  handleOverrideProjectorSubmit(data) {
    this.setState({
      projectorOverride: {
        modalOpen: false,
        enabled: true,
        ...data,
      },
    });
  }

  handleAddMoreMatchesCancel() {
    this.setState({
      addMoreMatchesModalOpen: false,
    });
  }

  handleAddMoreMatchesSubmit(matches, additionalMatchesPlayedPerTeam) {
    this.setState(
      {
        matches: this.state.matches.concat(matches),
        numMatchesPerTeam: this.state.numMatchesPerTeam + additionalMatchesPlayedPerTeam,
        addMoreMatchesModalOpen: false,
      },
      () => {
        this.writeBackup();
      }
    );
  }

  handleEditTeamNameCancel() {
    this.setState({
      editTeamNameModalOpen: false,
    });
  }

  handleEditTeamNameSubmit(oldName, newName) {
    let matches = this.state.matches;
    let teams = this.state.teams;
    let sortedRankings = this.state.sortedRankings;
    let finishedQualificationMatches = this.state.finishedQualificationMatches;
    let teamMenuOptions = this.state.teamMenuOptions;

    teams[oldName].name = newName;
    teams[newName] = teams[oldName];
    delete teams[oldName];

    matches.forEach((match, index) => {
      if (match.red1 === oldName) {
        match.red1 = newName;
      }
      if (match.red2 === oldName) {
        match.red2 = newName;
      }
      if (match.blue1 === oldName) {
        match.blue1 = newName;
      }
      if (match.blue2 === oldName) {
        match.blue2 = newName;
      }
    });

    sortedRankings.forEach((team, index) => {
      if (team.name === oldName) {
        team.name = newName;
      }
    });

    if (this.state.eliminations) {
      finishedQualificationMatches.forEach((match, index) => {
        if (match.red1 === oldName) {
          match.red1 = newName;
        }
        if (match.red2 === oldName) {
          match.red2 = newName;
        }
        if (match.blue1 === oldName) {
          match.blue1 = newName;
        }
        if (match.blue2 === oldName) {
          match.blue2 = newName;
        }
      });
    }

    teamMenuOptions.forEach((team) => {
      if (team.key === oldName) {
        team.key = newName;
        team.value = newName;
        team.text = newName;
      }
    });
    teamMenuOptions = teamMenuOptions.sort((a, b) => {
      return a.key.localeCompare(b.key);
    });

    this.setState(
      {
        matches: matches,
        finishedQualificationMatches: finishedQualificationMatches,
        teams: teams,
        teamMenuOptions: teamMenuOptions,
        sortedRankings: sortedRankings,
        editTeamNameModalOpen: false,
      },
      () => {
        this.writeBackup();
      }
    );
  }

  handleAddLateTeamCancel() {
    this.setState({
      addLateCompetitorModalOpen: false,
    });
  }

  handleAddLateTeamSubmit(name) {
    let matches = this.state.matches;
    let teams = this.state.teams;
    let sortedRankings = this.state.sortedRankings;
    let teamMenuOptions = this.state.teamMenuOptions;
    let unscoredMatches = matches.filter((match) => {
      return !match.scores;
    });

    let selectedMatches = [];
    for (let i = 0; i < this.state.numMatchesPerTeam && unscoredMatches.length > 0; i++) {
      selectedMatches.push(unscoredMatches.splice(Math.floor(Math.random() * unscoredMatches.length), 1)[0]);
    }

    let additionalMatchesNeeded = this.state.numMatchesPerTeam - selectedMatches.length;
    let allTeams = Object.keys(teams);
    let surrogateIndex = 0;

    let selectTeam = (match, teamIndex) => {
      if (teamIndex === 0) {
        return match.red1;
      } else if (teamIndex === 1) {
        return match.red2;
      } else if (teamIndex === 2) {
        return match.blue1;
      } else {
        return match.blue2;
      }
    };

    let replaceTeam = (match, teamIndex, team) => {
      if (teamIndex === 0) {
        match.red1 = team;
      } else if (teamIndex === 1) {
        match.red2 = team;
      } else if (teamIndex === 2) {
        match.blue1 = team;
      } else {
        match.blue2 = team;
      }
    };

    let pickTeamForMatch = (match) => {
      let team = null;
      do {
        team = allTeams[++surrogateIndex % allTeams.length];
      } while (match.red1 === team || match.red2 === team || match.blue1 === team || match.blue2 === team);
      return team;
    };

    let fillMatchWithSurrogates = (match) => {
      let surrogateInfo = {
        red1: match.red1 ? false : true,
        red2: match.red2 ? false : true,
        blue1: match.blue1 ? false : true,
        blue2: match.blue2 ? false : true,
      };
      if (!match.red1) {
        match.red1 = pickTeamForMatch(match);
      }
      if (!match.red2) {
        match.red2 = pickTeamForMatch(match);
      }
      if (!match.blue1) {
        match.blue1 = pickTeamForMatch(match);
      }
      if (!match.blue2) {
        match.blue2 = pickTeamForMatch(match);
      }
      match.surrogates = surrogateInfo;
    };

    let displacedTeams = [];
    while (selectedMatches.length > 0) {
      let selectedTeam = null;
      let selectedMatch = selectedMatches.pop();
      do {
        let index = Math.floor(Math.random() * 4);
        selectedTeam = selectTeam(selectedMatch, index);

        if (!displacedTeams.includes(selectedTeam)) {
          displacedTeams.push(selectedTeam);
          replaceTeam(selectedMatch, index, name);
          break;
        }
      } while (true);

      if (displacedTeams.length === 4) {
        matches.push({
          num: matches.length + 1,
          red1: displacedTeams[0],
          red2: displacedTeams[1],
          blue1: displacedTeams[2],
          blue2: displacedTeams[3],
          surrogates: {
            red1: false,
            red2: false,
            blue1: false,
            blue2: false,
          },
        });
        displacedTeams = [];
      }
    }

    if (displacedTeams.length > 0) {
      let match = {
        num: matches.length + 1,
      };

      if (displacedTeams.length >= 1) {
        match.red1 = displacedTeams[0];
      }
      if (displacedTeams.length >= 2) {
        match.red2 = displacedTeams[1];
      }
      if (displacedTeams.length >= 3) {
        match.blue1 = displacedTeams[2];
      } // blue 2 should nevee be present here
      fillMatchWithSurrogates(match);
      additionalMatchesNeeded--;
      matches.push(match);
    }

    while (additionalMatchesNeeded > 0) {
      let match = {
        num: matches.length + 1,
      };
      match.red1 = name;
      fillMatchWithSurrogates(match);
      additionalMatchesNeeded--;
      matches.push(match);
    }

    teams[name] = {
      name: name,
      rank: Object.keys(teams).length + 1,
      scoreHistory: {},
      totalRankingPoints: 0,
      totalPenaltyPoints: 0,
      totalPoints: 0,
      totalMatchScore: 0,
      totalWins: 0,
      totalLosses: 0,
      totalTies: 0,
    };

    sortedRankings.push(teams[name]);
    teamMenuOptions.push({
      key: name,
      value: name,
      text: name,
    });
    teamMenuOptions = teamMenuOptions.sort((a, b) => {
      return a.key.localeCompare(b.key);
    });

    this.setState(
      {
        matches: matches,
        teams: teams,
        teamMenuOptions: teamMenuOptions,
        sortedRankings: sortedRankings,
        addLateCompetitorModalOpen: false,
      },
      () => {
        this.writeBackup();
      }
    );
  }

  handleRemoveTeamCancel() {
    this.setState({
      removeCompetitorModalOpen: false,
    });
  }

  handleRemoveTeamSubmit(team, replacementsNeeded) {
    let matches = this.state.matches;
    for (let index in replacementsNeeded) {
      let replacement = replacementsNeeded[index];
      let match = matches.find((match) => {
        return match.num === replacement.num;
      });
      if (match.red1 === team) {
        match.red1 = replacement.selection;
        match.surrogates.red1 = true;
      }
      if (match.red2 === team) {
        match.red2 = replacement.selection;
        match.surrogates.red2 = true;
      }
      if (match.blue1 === team) {
        match.blue1 = replacement.selection;
        match.surrogates.blue1 = true;
      }
      if (match.blue2 === team) {
        match.blue2 = replacement.selection;
        match.surrogates.blue2 = true;
      }
    }
    this.setState(
      {
        matches: matches,
        removeCompetitorModalOpen: false,
        numTeams: this.state.numTeams - 1,
      },
      () => {
        this.writeBackup();
      }
    );
  }

  handleEditScheduleModalCancel() {
    this.setState({
      editScheduleModalOpen: false,
    });
  }

  handleEditScheduleModalSubmit(matches) {
    let schedule = this.state.matches;
    for (let i = 0; i < matches.length; i++) {
      schedule[i].red1 = matches[i].red1;
      schedule[i].red2 = matches[i].red2;
      schedule[i].blue1 = matches[i].blue1;
      schedule[i].blue2 = matches[i].blue2;
      schedule[i].surrogates = matches[i].surrogates;
    }

    this.setState({
      editScheduleModalOpen: false,
      matches: matches,
    });
  }

  handleRankingsScrollChange() {
    this.setState({
      rankingsScroll: !this.state.rankingsScroll,
    });
  }

  handleOpenAwardsSettings() {
    this.setState({
      awardsModalOpen: true,
    });
  }

  handleAwardsModalCancel() {
    this.setState({
      awardsModalOpen: false,
    });
  }

  handleChangeAwards(awards) {
    this.setState({
      awards: awards,
    });
  }

  handleSetActiveAward(awardName) {
    this.setState({
      activeAward: awardName,
      showAwardWinner: false,
    });
  }

  handleShowAwardWinner() {
    this.setState({
      showAwardWinner: true,
    });
  }

  handleSaveSettings(newState) {
    console.log("attempting to save new state from settings");
    console.log(newState);
    this.setState(newState, () => {
      this.writeBackup();
    });
  }

  loadBackup(backup) {
    backup.audio = this.state.audio;
    if (backup.eliminations) {
      backup.matches = Eliminations.relinkMatches(backup.matches);
    }
    this.setState(backup, () => {
      electron.ipcRenderer.send("app-loaded-schedule", true);
      electron.ipcRenderer.send("set-livescore-app-location", this.state.liveScore.appLocation);
    });
  }

  render() {
    return (
      <Router initialEntries={["/loadBackup"]} initialIndex={0}>
        <div>
          {this.state.redirectEnabled && <Redirect to={this.state.redirectLocation} />}
          <Route
            exact
            path="/loadBackup"
            render={() => (
              <SetupLoadBackup
                backup={this.props.backup}
                loadBackupHandler={(load) => {
                  if (load) {
                    this.loadBackup(this.props.backup);
                  }
                }}
              />
            )}
          />
          <Route
            exact
            path="/setupTeams"
            render={() => (
              <SetupMatchSchedule
                generateMatchesHandler={(matches, teams, numMatchesPerTeam) => {
                  let teamInfo = {};
                  for (let team in teams) {
                    teamInfo[teams[team]] = {
                      name: teams[team],
                      rank: Number(team) + 1,
                      scoreHistory: {},
                    };
                  }

                  const teamMenuOptions = teams
                    .map((team) => ({
                      key: team,
                      text: team,
                      value: team,
                    }))
                    .sort((a, b) => {
                      return a.key.localeCompare(b.key);
                    });

                  this.setState(
                    {
                      matches: matches,
                      teams: teamInfo,
                      teamMenuOptions: teamMenuOptions,
                      numTeams: teams.length,
                      numMatchesPerTeam: numMatchesPerTeam,
                      sortedRankings: teams.map((team) => {
                        return {
                          name: team,
                          rank: teamInfo[team].rank,
                          scoreHistory: [],
                        };
                      }),
                    },
                    () => {
                      this.writeBackup();
                    }
                  );
                }}
              />
            )}
          />
          <Route
            exact
            path="/"
            render={() => (
              <MainPage
                state={this.state}
                handleIncDecMatch={this.handleIncDecMatch.bind(this)}
                handleSetField={this.handleSetField.bind(this)}
                handleStartStopMatch={this.handleStartStopMatch.bind(this)}
                handleStartEliminations={this.handleStartEliminations.bind(this)}
                handleOverrideEliminationAdvancements={this.handleOverrideEliminationAdvancements.bind(this)}
                handleChangeProjectorMode={this.handleChangeProjectorMode.bind(this)}
                handleChangeOpModes={this.handleChangeOpModes.bind(this)}
                handleSubmitScores={this.handleSubmitScores.bind(this)}
                handleOverrideProjectorSubmit={this.handleOverrideProjectorSubmit.bind(this)}
                handleOverrideProjectorCancel={this.handleOverrideProjectorCancel.bind(this)}
                handleAddMoreMatchesSubmit={this.handleAddMoreMatchesSubmit.bind(this)}
                handleAddMoreMatchesCancel={this.handleAddMoreMatchesCancel.bind(this)}
                handleEditTeamNameSubmit={this.handleEditTeamNameSubmit.bind(this)}
                handleEditTeamNameCancel={this.handleEditTeamNameCancel.bind(this)}
                handleAddLateTeamSubmit={this.handleAddLateTeamSubmit.bind(this)}
                handleAddLateTeamCancel={this.handleAddLateTeamCancel.bind(this)}
                handleRemoveTeamSubmit={this.handleRemoveTeamSubmit.bind(this)}
                handleRemoveTeamCancel={this.handleRemoveTeamCancel.bind(this)}
                handleEditScheduleModalSubmit={this.handleEditScheduleModalSubmit.bind(this)}
                handleEditScheduleModalCancel={this.handleEditScheduleModalCancel.bind(this)}
                handleRankingsScrollChange={this.handleRankingsScrollChange.bind(this)}
                handleOpenAwardsSettings={this.handleOpenAwardsSettings.bind(this)}
                handleChangeAwards={this.handleChangeAwards.bind(this)}
                handleAwardsModalCancel={this.handleAwardsModalCancel.bind(this)}
                handleSetActiveAward={this.handleSetActiveAward.bind(this)}
                handleShowAwardWinner={this.handleShowAwardWinner.bind(this)}
              />
            )}
          />
          <Route
            exact
            path="/settings"
            render={() => <SettingsPage state={this.state} handleSaveSettings={this.handleSaveSettings.bind(this)} />}
          />
          <Route exact path="/projector" component={Projector} />
        </div>
      </Router>
    );
  }
}

export default App;
