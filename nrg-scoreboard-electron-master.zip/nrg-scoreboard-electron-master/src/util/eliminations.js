class Eliminations {
  static generateSchedule(startingAlliances, doubleElimination, allianceSelections) {
    let matches = [];
    let generatedMatches = 0;

    let roundSize = startingAlliances;
    let lastRound = [];
    while (roundSize >= 2) {
      let thisRound = [];
      let matchesInThisRound = roundSize / 2;
      let roundName = this.roundName(roundSize, startingAlliances);
      let shortRoundName = this.shortRoundName(roundSize, startingAlliances);

      for (let i = 0; i < roundSize / 2; i++) {
        let redTeam = [null, null];
        let blueTeam = [null, null];

        if (roundSize === startingAlliances) {
          // this is the first round, fill teams according to page 112:
          // https://firstfrc.blob.core.windows.net/frc2018/Manual/Sections/10-Tournaments.pdf
          let offset = Math.floor(i / 2);
          if (i % 2 === 0) {
            // take from the outer edges of the seeded alliances
            redTeam = allianceSelections[offset];
            blueTeam = allianceSelections[startingAlliances - 1 - offset];
          } else {
            // take from the inner edges of the seeded alliances
            redTeam = allianceSelections[Math.floor(startingAlliances / 2) - 1 - offset];
            blueTeam = allianceSelections[Math.floor(startingAlliances / 2) + offset];
          }
        }

        let match1 = this.generateMatch(generatedMatches + i + 1, redTeam, blueTeam);
        match1.eliminations.title = `${roundName} ${i + 1} of ${matchesInThisRound * (doubleElimination ? 2 : 1)}`;
        match1.eliminations.shortTitle = `${shortRoundName}${i + 1}`;

        if (doubleElimination) {
          let match2 = this.generateMatch(generatedMatches + i + matchesInThisRound + 1, redTeam, blueTeam);
          match2.eliminations.title = `${roundName} ${i + matchesInThisRound + 1} of ${roundSize}`;
          match2.eliminations.shortTitle = `${shortRoundName}${i + matchesInThisRound + 1}`;

          let tiebreaker = this.generateMatch(generatedMatches + i + matchesInThisRound * 2 + 1, redTeam, blueTeam);
          tiebreaker.eliminations.title = `${match1.eliminations.shortTitle}/${match2.eliminations.shortTitle} Tiebreaker`;
          tiebreaker.eliminations.shortTitle = `${shortRoundName}-TB${i + 1}`;
          tiebreaker.eliminations.hide = true;
          tiebreaker.eliminations.tieSources = [match1, match2];

          if (tiebreaker.eliminations.shortTitle === "F-TB1") {
            // better name for final tiebreaker
            tiebreaker.eliminations.title = "Final Tiebreaker";
          }

          match1.eliminations.dependant = match2;
          match2.eliminations.dependant = match1;
          match1.eliminations.tiebreaker = tiebreaker;
          match2.eliminations.tiebreaker = tiebreaker;

          thisRound.push([match1, match2, tiebreaker]);
          matches.push(match1);
          matches.push(match2);
          matches.push(tiebreaker);
        } else {
          thisRound.push([match1]);
          matches.push(match1);
        }

        if (lastRound.length > 0) {
          for (let match in lastRound[i * 2]) {
            // these matches advance to this match's red alliance
            lastRound[i * 2][match].eliminations.destination.matches = thisRound[thisRound.length - 1];
            lastRound[i * 2][match].eliminations.destination.team = "red";
          }
          for (let match in lastRound[i * 2 + 1]) {
            // these matches advanced to this match's blue alliance
            lastRound[i * 2 + 1][match].eliminations.destination.matches = thisRound[thisRound.length - 1];
            lastRound[i * 2 + 1][match].eliminations.destination.team = "blue";
          }
        }
      }

      generatedMatches += doubleElimination ? (roundSize / 2) * 3 : roundSize / 2;
      lastRound = thisRound;
      thisRound = [];
      roundSize = roundSize / 2;
    }

    return matches.sort((a, b) => a.num - b.num);
  }

  static generateMatch(num, redTeam, blueTeam) {
    return {
      num: num,
      red1: redTeam[0],
      red2: redTeam[1],
      blue1: blueTeam[0],
      blue2: blueTeam[1],
      eliminations: {
        dependant: null,
        destination: {
          team: undefined,
          matches: []
        }
      }
    };
  }

  static roundName(roundSize, startingAlliances) {
    let remainingRounds = Math.log2(roundSize) - 1;
    switch (remainingRounds) {
      case 2:
        return "Quarterfinals";
      case 1:
        return "Semifinals";
      case 0:
        return "Finals";
      default:
        return "Round " + Math.log2(startingAlliances) - remainingRounds;
    }
  }

  static shortRoundName(roundSize, startingAlliances) {
    let remainingRounds = Math.log2(roundSize) - 1;
    switch (remainingRounds) {
      case 2:
        return "QF";
      case 1:
        return "SF";
      case 0:
        return "F";
      default:
        return "R" + Math.log2(startingAlliances) - remainingRounds;
    }
  }

  static advance(updatedMatch) {
    let winner = this.winner(updatedMatch);
    if (updatedMatch.eliminations.dependant) {
      let otherWinner = this.winner(updatedMatch.eliminations.dependant);
      if (winner && otherWinner && otherWinner !== "tie" && winner === otherWinner) {
        this.updateDestinations(updatedMatch, winner);
      }

      if (updatedMatch.eliminations.tiebreaker) {
        updatedMatch.eliminations.tiebreaker.eliminations.hide = !(
          winner &&
          otherWinner &&
          (winner === "tie" || otherWinner === "tie" || winner !== otherWinner)
        );
      }
    } else if (winner && winner !== "tie") {
      this.updateDestinations(updatedMatch, winner);
    }
  }

  static winner(match) {
    if (!match.scores || match.scores.red === undefined || match.scores.blue === undefined) {
      return null;
    } else if (match.scores.red < match.scores.blue) {
      return "blue";
    } else if (match.scores.red > match.scores.blue) {
      return "red";
    } else {
      return "tie";
    }
  }

  static updateDestinations(match, winner) {
    for (let index in match.eliminations.destination.matches) {
      let destination = match.eliminations.destination.matches[index];
      if (
        destination[match.eliminations.destination.team + "1"] !== match[winner + "1"] ||
        destination[match.eliminations.destination.team + "2"] !== match[winner + "2"]
      ) {
        destination.scores = undefined;
      }

      destination[match.eliminations.destination.team + "1"] = match[winner + "1"];
      destination[match.eliminations.destination.team + "2"] = match[winner + "2"];
    }
  }

  static unlinkMatches(linkedMatches) {
    let unlinkedMatches = [];
    for (let i = 0; i < linkedMatches.length; i++) {
      if (!linkedMatches[i].eliminations) continue;

      let destinationMatches = [];
      for (let j = 0; j < linkedMatches[i].eliminations.destination.matches.length; j++) {
        destinationMatches.push(linkedMatches[i].eliminations.destination.matches[j].num);
      }
      let tiebreaker = undefined;
      if (linkedMatches[i].eliminations.tiebreaker) {
        tiebreaker = linkedMatches[i].eliminations.tiebreaker.num;
      }
      let dependant = undefined;
      if (linkedMatches[i].eliminations.dependant) {
        dependant = linkedMatches[i].eliminations.dependant.num;
      }
      let tieSources = undefined;
      if (linkedMatches[i].eliminations.tieSources) {
        tieSources = [];
        linkedMatches[i].eliminations.tieSources.forEach(tieSource => {
          tieSources.push(tieSource.num);
        })
      }
      unlinkedMatches.push({
        ...linkedMatches[i],
        eliminations: {
          ...linkedMatches[i].eliminations,
          tiebreaker: tiebreaker,
          dependant: dependant,
          destination: {
            ...linkedMatches[i].eliminations.destination,
            matches: destinationMatches
          },
          tieSources: tieSources
        }
      });
    }
    return unlinkedMatches;
  }

  static relinkMatches(matches) {
    for (let i = 0; i < matches.length; i++) {
      let destinationMatches = [];
      for (let j = 0; j < matches[i].eliminations.destination.matches.length; j++) {
        destinationMatches.push(matches[matches[i].eliminations.destination.matches[j] - 1]);
      }
      let tiebreaker = undefined;
      if (matches[i].eliminations.tiebreaker) {
        tiebreaker = matches[matches[i].eliminations.tiebreaker - 1];
      }
      let dependant = undefined;
      if (matches[i].eliminations.dependant) {
        dependant = matches[matches[i].eliminations.dependant - 1];
      }
      let tieSources = undefined;
      if (matches[i].eliminations.tieSources) {
        tieSources = [];
        matches[i].eliminations.tieSources.forEach(tieSource => {
          tieSources.push(tieSource.num);
        })
      }
      matches[i].eliminations = {
        ...matches[i].eliminations,
        tiebreaker: tiebreaker,
        dependant: dependant,
        destination: {
          ...matches[i].eliminations.destination,
          matches: destinationMatches
        },
        tieSources: tieSources
      };
    }
    return matches;
  }
}

export default Eliminations;
