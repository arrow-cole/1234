class ScheduleGenerator {
  constructor(generationStyle, enforcePlaytimeEquity, useSurrogateMatches) {
    this.generationStyle = generationStyle;
    this.enforcePlaytimeEquity = enforcePlaytimeEquity;
    this.useSurrogateMatches = useSurrogateMatches;
    this.startingMatchNumber = 1;
  }

  generateSchedule(numMatches, teams) {
    let numMatchesInSchedule = this.generationStyle === "total" ? numMatches : (numMatches * teams.length) / 4;
    let randomize = array => {
      return [].concat(array).sort(() => Math.random() - 0.5);
    };
    let surrogateCheck = (match, position) => {
      return (
        !this.enforcePlaytimeEquity &&
        this.useSurrogateMatches &&
        4 * (numMatchesInSchedule - match - 1) + (4 - position) < teams.length
      );
    };
    let schedule = [];
    let currentOrder = randomize(teams);
    let isSurrogate = false;
    for (let i = 0; i < numMatchesInSchedule; i++) {
      let matchTeams = [];
      let matchSurrogates = [];
      for (let j = 0; j < 4; j++) {
        if (currentOrder.length === 0) {
          currentOrder = randomize(teams);
          isSurrogate = surrogateCheck(i, j);
        }
        let team;
        while (true) {
          team = currentOrder.pop();
          if (matchTeams.includes(team)) {
            currentOrder.unshift(team);
          } else {
            break;
          }
        }
        matchTeams.push(team);
        matchSurrogates.push(isSurrogate);
      }
      schedule.push({
        num: i + this.startingMatchNumber,
        red1: matchTeams[0],
        red2: matchTeams[1],
        blue1: matchTeams[2],
        blue2: matchTeams[3],
        surrogates: {
          red1: matchSurrogates[0],
          red2: matchSurrogates[1],
          blue1: matchSurrogates[2],
          blue2: matchSurrogates[3]
        }
      });
    }

    return schedule;
  }
}

export default ScheduleGenerator;
