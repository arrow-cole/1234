class Rankings {

  static RankingOrderOptions = {
    RANKING_POINTS: 1,
    AVERAGE_MATCH_SCORE: 2,
    LEAST_PENALTY_POINTS: 3,
    AVERAGE_NON_PENALTY_POINTS: 4,
    WINS: 5
  };

  static defaultRankingOrders() {
    return [
      Rankings.RankingOrderOptions.RANKING_POINTS,
      Rankings.RankingOrderOptions.LEAST_PENALTY_POINTS,
      Rankings.RankingOrderOptions.WINS,
      Rankings.RankingOrderOptions.AVERAGE_NON_PENALTY_POINTS,
      Rankings.RankingOrderOptions.AVERAGE_MATCH_SCORE
    ];
  }

  static rank(teams, rankingPriorities) {
    for (let t in teams) {
      this.calculateTotalStatistics(teams[t]);
    }

    let sortedTeams = Object.values(teams).sort((one, two) => {
      let result;
      if ((result = this.compareBy(rankingPriorities[0], one, two)) !== 0) {
        return result;
      } else if ((result = this.compareBy(rankingPriorities[1], one, two)) !== 0) {
        return result;
      } else if ((result = this.compareBy(rankingPriorities[2], one, two)) !== 0) {
        return result;
      } else if ((result = this.compareBy(rankingPriorities[3], one, two)) !== 0) {
        return result;
      } else if ((result = this.compareBy(rankingPriorities[4], one, two)) !== 0) {
        return result;
      } else {
        return Math.random() > 0.5 ? 1 : -1;
      }
    });

    return sortedTeams;
  }

  static compareBy(option, team1, team2) {
    let team1Played = Object.values(team1.scoreHistory).length;
    let team2Played = Object.values(team2.scoreHistory).length;
    switch (option) {
      case Rankings.RankingOrderOptions.RANKING_POINTS:
        return -this.normalize(
          this.zeroIfNaN(team1.totalRankingPoints / team1Played) -
            this.zeroIfNaN(team2.totalRankingPoints / team2Played)
        ); // negate to rank descending
      case Rankings.RankingOrderOptions.AVERAGE_MATCH_SCORE:
        return -this.normalize(
          this.zeroIfNaN(team1.totalMatchScore / team1Played) - this.zeroIfNaN(team2.totalMatchScore / team2Played)
        ); // negate to rank descending
      case Rankings.RankingOrderOptions.AVERAGE_NON_PENALTY_POINTS:
        return -this.normalize(
          this.zeroIfNaN(team1.totalPoints / team1Played) - this.zeroIfNaN(team2.totalPoints / team2Played)
        ); // negate to rank descending
      case Rankings.RankingOrderOptions.LEAST_PENALTY_POINTS:
        return team1.totalPenaltyPoints - team2.totalPenaltyPoints;
      case Rankings.RankingOrderOptions.WINS:
        return -(team1.totalWins - team2.totalWins); // negate to rank descending
      default:
        throw new Error("invalid ranking option");
    }
  }

  static zeroIfNaN(value) {
    if (isNaN(value) || !isFinite(value)) {
      return 0.0;
    }
    return value;
  }

  static normalize(value) {
    return value / Math.abs(value) || 0;
  }

  static calculateTotalStatistics(team) {
    team.totalRankingPoints = 0;
    team.totalPenaltyPoints = 0;
    team.totalPoints = 0;
    team.totalMatchScore = 0;
    team.totalWins = 0;
    team.totalLosses = 0;
    team.totalTies = 0;
    for (let index in team.scoreHistory) {
      let match = team.scoreHistory[index];
      team.totalRankingPoints += match.rankingPoints;
      team.totalPenaltyPoints += match.penaltyPoints;
      team.totalPoints += match.points;
      team.totalMatchScore += match.matchScore;
      team.totalWins += match.win ? 1 : 0;
      team.totalLosses += match.loss ? 1 : 0;
      team.totalTies += match.tie ? 1 : 0;
    }
  }
}

export default Rankings;
