const os = window.require("os");

const isDev = !window.require("@electron/remote").app.isPackaged;

function getBackupFilePath() {
  if (isDev) {
    return "backup.json";
  }

  switch (os.platform()) {
    case "win32":
      return window.process.env.PORTABLE_EXECUTABLE_DIR + "\\backup.json";
    case "darwin":
      return "~/.nrg-backup.json";
    default:
      return "backup.json";
  }
}

function getScheduleCSVFilePath() {
  if (isDev) {
    return "schedule.csv";
  }

  switch (os.platform()) {
    case "win32":
      return window.process.env.PORTABLE_EXECUTABLE_DIR + "\\schedule.csv";
    case "darwin":
      return "~/.nrg-schedule.csv";
    default:
      return "schedule.csv";
  }
}

export { getBackupFilePath, getScheduleCSVFilePath };
