const Mqtt = require("./mqtt");
const LiveScore = require("./livescore.js");
const Menu = require("./menu");

const electron = require("electron");
const remoteMain = require("@electron/remote/main");
remoteMain.initialize();

const app = electron.app;
const BrowserWindow = electron.BrowserWindow;

const path = require("path");
const isDev = require("electron-is-dev");

var mqtt = new Mqtt();
var liveScore = new LiveScore();
liveScore.init();

let controllerWindow;
let projectorWindow;
let menu = new Menu(
  () => {
    return controllerWindow;
  },
  () => {
    return projectorWindow;
  },
  createProjectorWindow
);

const ipcMain = electron.ipcMain;
ipcMain.on("update-projector", (o, data) => {
  if (projectorWindow !== null) {
    projectorWindow?.webContents.send("update-projector", data);
  }
});
ipcMain.on("request-is-projector", (event, data) => {
  event.sender.send("set-is-projector", projectorWindow !== null && event.sender === projectorWindow.webContents);
});
ipcMain.on("open-projector-devtools", (event, data) => {
  if (projectorWindow !== null) {
    projectorWindow.openDevTools();
  }
});
ipcMain.on("time-update", (event, data) => {
  mqtt.publishTime(data.field, data.time);
});
ipcMain.on("opMode-update", (event, data) => {
  mqtt.publishOpMode(data.field, data.opMode);
});
ipcMain.on("publish-robot-command", (event, data) => {
  mqtt.publishCommand(data.field, data.robot, data.command);
});
mqtt.on("robot-status-update", (field, robot, opMode) => {
  controllerWindow?.webContents.send("robot-status-update", {
    field: field,
    robot: robot,
    opMode: opMode,
  });
});
mqtt.on("fcs-status-update", (field, status) => {
  controllerWindow?.webContents.send("fcs-status-update", {
    field: field,
    status: status,
  });
});
mqtt.on("mqtt-connection-change", (status) => {
  controllerWindow?.webContents.send("mqtt-connection-change", status);
});
ipcMain.on("request-mqtt-connection-state", () => {
  controllerWindow?.webContents.send("mqtt-connection-change", mqtt.connected() ? "connected" : "disconnected");
});
ipcMain.on("set-livescore-app-location", (event, appLocation) => {
  liveScore.serveLiveScoreApp(appLocation);
});
liveScore.on("phone-count-update", (data) => {
  controllerWindow?.webContents.send("livescore-phone-count-update", data);
});
liveScore.on("score-update", (data) => {
  data = JSON.parse(data);
  controllerWindow?.webContents.send("livescore-score-update", data);
});
liveScore.on("submit-final-scores", (data) => {
  data = JSON.parse(data);
  controllerWindow?.webContents.send("livescore-submit-final-scores", data);
});

mqtt.connect("mqtt://localhost");

function createControllerWindow() {
  controllerWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
    icon: path.join(__dirname, "assets/icons/png/logo-1024.png"),
  });
  remoteMain.enable(controllerWindow.webContents);
  controllerWindow.loadURL(isDev ? "http://localhost:3000/" : `file://${path.join(__dirname, "../build/index.html")}`);
  controllerWindow.on("close", (e) => {
    menu.confirmClose(e);
  });
  controllerWindow.on("closed", () => (controllerWindow = null));
  if (process.platform === "darwin") {
    electron.Menu.setApplicationMenu(menu.build());
  } else {
    controllerWindow.setMenu(menu.build());
  }
}

function createProjectorWindow() {
  projectorWindow = new BrowserWindow({
    width: 900,
    height: 680,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });
  remoteMain.enable(projectorWindow.webContents);
  projectorWindow.loadURL(isDev ? "http://localhost:3000/" : `file://${path.join(__dirname, "../build/index.html")}`);
  projectorWindow.setMenu(null);
  projectorWindow.on("closed", () => {
    projectorWindow = null;
    if (menu.isProjectorReopenRequested()) {
      createProjectorWindow();
    }
  });
}

app.on("ready", createControllerWindow);
app.on("ready", createProjectorWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  if (controllerWindow === null) {
    createControllerWindow();
  }
  if (projectorWindow === null) {
    createProjectorWindow();
  }
});
