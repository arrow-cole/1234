var mqtt = require("mqtt");

class Mqtt {
  constructor() {
    this.client = null;
    this.robotStatusHandlers = [];
    this.fcsStatusHandlers = [];
    this.mqttStatusHandlers = [];
    this.robotStatus = {
      field1: {
        R1: "norobot",
        R2: "norobot",
        B1: "norobot",
        B2: "norobot"
      },
      field2: {
        R1: "norobot",
        R2: "norobot",
        B1: "norobot",
        B2: "norobot"
      }
    };
    this.fcsStatus = {
      field1: "disconnected",
      field2: "disconnected"
    };

    setInterval(() => {
      let now = new Date();
      if (now - this.fcsStatus["field1"] > 15000) {
        this.fcsStatusHandlers.forEach(handler => {
          handler(1, "indeterminate");
        });
      }
      if (now - this.fcsStatus["field2"] > 15000) {
        this.fcsStatusHandlers.forEach(handler => {
          handler(2, "indeterminate");
        });
      }
    }, 2500);
  }

  connect(url) {
    this.client = mqtt.connect(url);
    this.client.on("connect", () => {
      this.mqttStatusHandlers.forEach(handler => {
        handler("connected");
      });
    });
    this.client.subscribe(["/field/+/robot/+/status", "/field/+/lastseen"]);
    this.client.on("message", (topic, message, packet) => {
      if (topic.match(/^\/field\/.*\/robot\/[RB][12]\/status$/)) {
        let field = topic.split("/")[2];
        let robot = topic.split("/")[4];
        if (this.robotStatus["field" + field][robot] != message.toString()) {
          this.robotStatus["field" + field][robot] = message.toString();
          this.robotStatusHandlers.forEach(handler => {
            handler(field, robot, message.toString());
          });
        }
      } else if (topic.match(/^\/field\/.*\/lastseen/)) {
        let field = topic.split("/")[2];
        if (message.toString() == "disconnected") {
          this.fcsStatus["field" + field] = "disconnected";
          this.fcsStatusHandlers.forEach(handler => {
            handler(field, "disconnected");
          });
        } else {
          let field = topic.split("/")[2];
          let time = new Date();
          this.fcsStatusHandlers.forEach(handler => {
            handler(field, "connected");
          });
          this.fcsStatus["field" + field] = time;
        }
      }
    });

    this.client.on("close", () => {
      this.mqttStatusHandlers.forEach(handler => {
        handler("disconnected");
      });
    });
    this.client.on("offline", () => {
      this.mqttStatusHandlers.forEach(handler => {
        handler("disconnected");
      });
    });
  }

  disconnect() {
    if (this.client == null) return;

    this.mqttStatusHandlers.forEach(handler => {
      handler("disconnected");
    });

    this.client.disconnect();
    this.client = null;
  }

  connected() {
    if (this.client == null) return false;
    else return this.client.connected;
  }

  publishOpMode(field, opMode) {
    if (this.client == null) return;

    this.client.publish(`/field/${field}/opMode`, opMode, { qos: 1, retain: true });
  }

  publishTime(field, time) {
    if (this.client == null) return;

    this.client.publish(`/field/${field}/time`, time.toString(), { qos: 0, retain: false });
  }

  publishCommand(field, robot, command) {
    if (this.client == null) return;

    robots = ["R1", "R2", "B1", "B2"];
    if (!robots.includes(robot)) {
      throw new Error(robot + " is not a valid robot");
    }

    this.client.publish(`/field/${field}/robot/${robot}/control`, command, { qos: 1, retain: false });
  }

  on(event, handler) {
    if (event === "fcs-status-update") {
      this.fcsStatusHandlers.push(handler);
    } else if (event === "robot-status-update") {
      this.robotStatusHandlers.push(handler);
    } else if (event === "mqtt-connection-change") {
      this.mqttStatusHandlers.push(handler);
    }
  }
}

module.exports = Mqtt;
