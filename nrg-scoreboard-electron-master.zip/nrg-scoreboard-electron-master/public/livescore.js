var express = require("express");
var socketIoServer = express();
var http = require("http").createServer(socketIoServer);
var io = require("socket.io")(http);

class LiveScore {
  constructor() {
    this.connections = 0;
    this.phoneCountHandlers = [];
    this.scoreUpdateHandlers = [];
    this.submitFinalScoresHandlers = [];
  }

  init() {
    socketIoServer.get("/", function(req, res) {
      res.send("index");
      console.log("get / ");
    });

    this.server = io;

    io.on(
      "connection",
      function(socket) {
        this.phoneCountHandlers.forEach(handler => {
          handler(++this.connections);
        });
        socket.on("disconnect", () => {
          this.phoneCountHandlers.forEach(handler => {
            handler(--this.connections);
          });
        });
        socket.on("score-update", data => {
          this.scoreUpdateHandlers.forEach(handler => {
            handler(data);
          });
        });
        socket.on("submit-final-scores", data => {
          this.submitFinalScoresHandlers.forEach(handler => {
            handler(data);
          });
        });
      }.bind(this)
    );

    http.listen(2771, function() {
      console.log("livescore server listening on *:2771");
    });
  }

  serveLiveScoreApp(appLocation) {
    if (this.liveScoreServer) {
      this.liveScoreServer.close();
    }
    let server = express();
    server.use(express.static(appLocation));
    this.liveScoreServer = server.listen(80);
  }

  on(event, handler) {
    if (event === "phone-count-update") {
      this.phoneCountHandlers.push(handler);
    } else if (event === "score-update") {
      this.scoreUpdateHandlers.push(handler);
    } else if (event === "submit-final-scores") {
      this.submitFinalScoresHandlers.push(handler);
    }
  }
}

module.exports = LiveScore;
