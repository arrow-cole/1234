const electron = require("electron");
const app = electron.app;
const isDev = require("electron-is-dev");

class Menu {
  constructor(getControllerWindow, getProjectorWindow, createProjectorWindow) {
    this.getControllerWindow = getControllerWindow;
    this.getProjectorWindow = getProjectorWindow;
    this.createProjectorWindow = createProjectorWindow;

    electron.ipcMain.on("app-loaded-schedule", (e, state) => {
      this.setMenuItemsEnabled(state);
      if (!state) {
        this.menu.getMenuItemById("disable-projector-override").enabled = false;
      }
    });

    this.setMenuItemsEnabled.bind(this);
    this.confirmClose.bind(this);
    this.isProjectorReopenRequested.bind(this);
    this.build.bind(this);
  }

  setMenuItemsEnabled(state) {
    this.menu.getMenuItemById("export-schedule-to-csv").enabled = state;
    this.menu.getMenuItemById("override-projector-display").enabled = state;
    this.menu.getMenuItemById("add-more-matches").enabled = state;
    this.menu.getMenuItemById("edit-schedule").enabled = state;
    this.menu.getMenuItemById("edit-team-names").enabled = state;
    this.menu.getMenuItemById("add-late-competitor").enabled = state;
    this.menu.getMenuItemById("remove-competitor").enabled = state;
  }

  confirmClose(e) {
    var choice = electron.dialog.showMessageBoxSync(this.getControllerWindow(), {
      type: "question",
      buttons: ["Yes", "No"],
      title: "Confirm",
      message: "Are you sure you want to quit?",
    });

    if (choice === 1 && e) {
      e.preventDefault();
    } else if (choice === 0) {
      if (this.getProjectorWindow() !== null) {
        this.getProjectorWindow().close();
      }
      if (this.getControllerWindow() !== null) {
        this.getControllerWindow().destroy(); // don't call handlers
      }
    }
  }

  isProjectorReopenRequested() {
    let value = this.reopenProjectorWindow;
    this.reopenProjectorWindow = false;
    return value;
  }

  build() {
    let menu = this;
    let isMac = process.platform === "darwin";
    const template = [
      ...(isMac
        ? [
            {
              label: app.getName(),
              submenu: [
                { role: "about" },
                { type: "separator" },
                {
                  label: "Settings",
                  click() {
                    menu.getControllerWindow().webContents?.send("menu-action", "open-settings");
                  },
                },
                { type: "separator" },
                { role: "services" },
                { type: "separator" },
                { role: "hide" },
                { role: "hideothers" },
                { role: "unhide" },
                { type: "separator" },
                { role: "quit" },
              ],
            },
          ]
        : []),
      {
        label: "File",
        submenu: [
          {
            label: isMac ? "Close" : "Quit",
            click() {
              menu.confirmClose();
            },
          },
        ],
      },
      {
        label: "Edit",
        submenu: [
          { role: "undo" },
          { role: "redo" },
          { type: "separator" },
          { role: "cut" },
          { role: "copy" },
          { role: "paste" },
          ...(isMac
            ? [
                { role: "pasteAndMatchStyle" },
                { role: "delete" },
                { role: "selectAll" },
                { type: "separator" },
                {
                  label: "Speech",
                  submenu: [{ role: "startspeaking" }, { role: "stopspeaking" }],
                },
              ]
            : [{ role: "delete" }, { type: "separator" }, { role: "selectAll" }]),
          ...(!isMac
            ? [
                { type: "separator" },
                {
                  label: "Settings",
                  click() {
                    menu.getControllerWindow().webContents?.send("menu-action", "open-settings");
                  },
                },
              ]
            : []),
        ],
      },
      {
        label: "Projector",
        submenu: [
          {
            id: "toggle-projector-fullscreen",
            label: "Toggle Projector Fullscreen",
            type: "checkbox",
            click(menuItem) {
              if (menu.getProjectorWindow() != null) {
                menu.getProjectorWindow().setFullScreen(menuItem.checked);
              }
            },
          },
          {
            id: "override-projector-display",
            label: "Override Projector Display",
            enabled: false,
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "manual-override");
              menu.menu.getMenuItemById("disable-projector-override").enabled = true;
            },
          },
          {
            id: "disable-projector-override",
            label: "Disable Override",
            enabled: false,
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "disable-override");
              menu.menu.getMenuItemById("disable-projector-override").enabled = false;
            },
          },
          {
            label: "Reopen Projector Window",
            click() {
              if (menu.getProjectorWindow() !== null) {
                menu.reopenProjectorWindow = true;
                menu.getProjectorWindow().close();
                menu.menu.getMenuItemById("toggle-projector-fullscreen").checked = false;
              } else {
                menu.createProjectorWindow();
              }
            },
          },
        ],
      },
      {
        label: "Schedule",
        submenu: [
          {
            label: "Generate New Match Schedule",
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "generate-schedule");
              menu.setMenuItemsEnabled(false);
            },
          },
          {
            label: "Load New Schedule From CSV",
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "load-schedule-csv");
            },
          },
          {
            label: "Reload From Backup",
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "reload-from-backup");
            },
          },
          { type: "separator" },
          {
            id: "export-schedule-to-csv",
            label: "Export Schedule to CSV",
            enabled: false,
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "export-schedule-to-csv");
            },
          },
          { type: "separator" },
          {
            id: "add-more-matches",
            label: "Add More Matches to Schedule",
            enabled: false,
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "add-more-matches");
            },
          },
          {
            id: "edit-schedule",
            label: "Edit Schedule",
            enabled: false,
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "edit-schedule");
            },
          },
        ],
      },
      {
        label: "Teams",
        submenu: [
          {
            id: "edit-team-names",
            label: "Edit Team Names",
            enabled: false,
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "edit-team-names");
            },
          },
          {
            id: "add-late-competitor",
            label: "Add Late Competitor",
            enabled: false,
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "add-late-competitor");
            },
          },
          {
            id: "remove-competitor",
            label: "Remove Competitor",
            enabled: false,
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "remove-competitor");
            },
          },
        ],
      },
      {
        label: "Help",
        submenu: [
          {
            label: "Open in GitHub",
            click() {
              electron.shell.openExternal("https://github.com/CodeRed2771/nrg-scoreboard-electron");
            },
          },
          { type: "separator" },
          ...(isDev ? [{ role: "reload" }] : []),
          {
            label: "Open Developer Tools",
            accelerator: "CommandOrControl+Alt+I",
            click() {
              if (menu.getControllerWindow() !== null) {
                menu.getControllerWindow().webContents.openDevTools();
              }
            },
          },
          {
            label: "Open Projector Dev Tools",
            accelerator: "CommandOrControl+Shift+Alt+I",
            click() {
              if (menu.getProjectorWindow() !== null) {
                menu.getProjectorWindow().webContents.openDevTools();
              }
            },
          },
          { type: "separator" },
          {
            label: "Help",
            click() {
              menu.getControllerWindow().webContents?.send("menu-action", "open-help");
            },
          },
        ],
      },
    ];
    this.menu = electron.Menu.buildFromTemplate(template);
    return this.menu;
  }
}

module.exports = Menu;
