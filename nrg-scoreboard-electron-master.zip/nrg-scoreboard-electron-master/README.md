# NRG Scoreboard

This is the NRG Scoreboard / presentation software.

Historical note: this is the version of the application that has been used in competitions since summer 2019. For the old version, see the [NRGScoreboard repo](https://github.com/CodeRed2771/NRGScoreboard).

## Related Repos

- [NRG FCS](https://github.com/CodeRed2771/NRG-FCS)
- [NRG Robot](https://github.com/CodeRed2771/nrg-robot)
- [NRG 2019 Live Score App](https://github.com/CodeRed2771/nrg-live-score-2019)
- [NRG 2021 Live Score App](https://github.com/CodeRed2771/nrg-live-score-2021)

## Development

### Setup

- Ensure you have NodeJS installed and on your PATH
- Install [Yarn](https://yarnpkg.com/getting-started/install)
- Install app dependencies: `yarn install`

### Running the app in development

Use `yarn start` to run the app in development mode. This will start the react app on localhost:3000 and launch the electron window. Changes to files should hot reload in the electron window.

### Building

Run `yarn dist` to build a standalone executable of the application. Tested on macOS and Windows.

## Live Score

The scoreboard starts an express server on port 80 to serve the livescore application. In the scoreboard settings, choose the Live Score app location and then enter your machine's IP address on a phone to use the app.

Note: The console prints out that the livescore app is running on port 2771. This is for testing purposes and should not be used at this time.

## Using the Scoreboard

TODO

## Integration with FCS

TODO
